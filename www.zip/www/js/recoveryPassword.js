$("document").ready(function(){
	localStorage.setItem("pageNow", "recoveryPassword");
	
	$("body div#recoveryPassword form#recoveryPassword label input").focus(function(){
		$(this).css("border", "1px solid #f5f6fa");
	});
	
	$("body div#recoveryPassword form#recoveryPassword").submit(function(e){
		e.preventDefault();
		
		let email = $("body div#recoveryPassword form#recoveryPassword label #email").val();
		
		if(email.length == 0){
			$("body div#recoveryPassword form#recoveryPassword label #email").css("border", "1px solid red");
			M.toast({html: "Preencha o campo corretamente.", classes: "red", displayLength: 2000});
		}
		else if(verifyEmail(email) == false){
			$("body div#recoveryPassword form#recoveryPassword label #email").css("border", "1px solid red");
			M.toast({html: "E-mail inválido.", classes: "red", displayLength: 2000});
		}
		else{
			dialog.startLoader("Enviando e-mail de recuperação de senha...");
			setTimeout(function(){
				dialog.stopLoader();				
			}, 3000);
		}
	});
	
	$("body div#recoveryPassword form#recoveryPassword p#login").click(function(){
		goToPage("login");
	});
});
function verifyEmail(email){
	let x = email;
	let atpos = x.indexOf("@");
	let dotpos = x.lastIndexOf(".");
	if (atpos<1 || dotpos<atpos+2 || dotpos+2>=x.length){
		return false;
	}
	else{
		return true;
	}
}