$("document").ready(function(){
	localStorage.setItem("pageNow", "options");
	
	$("body table tr td.button button#login").click(function(){
		goToPage("login");
	});
	
	$("body table tr td.button button#register").click(function(){
		goToPage("register");
	});
});