var dialog = {
	startLoader: function(message, title = ""){
		cordova.plugin.pDialog.init({
			theme: "DEVICE_LIGHT",
			progressStyle: "SPINNER",
			cancelable: false,
			title: title,
			message: message
		});
	},
	stopLoader: function(){
		cordova.plugin.pDialog.dismiss();
	},
	alert: function(message, callback = function(){}, title = "", buttonName = "Ok"){
		navigator.notification.alert(message, callback, title, buttonName);
	}
};
