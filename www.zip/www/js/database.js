var database = null;
function bd(){
	database = openDatabase("EnglishSwift", "1.0", "EnglishSwift", 1024 * 1024);
	if(database){
		database.transaction(function(transaction){			
		
			transaction.executeSql('CREATE TABLE IF NOT EXISTS `user` (`email` VARCHAR(200) NOT NULL, `fullName` VARCHAR(120) NOT NULL, `birthDate` VARCHAR(10) NOT NULL, `phoneNumber` VARCHAR(15) NOT NULL, `picture` VARCHAR(205) , `dateRegistration` VARCHAR(10) NOT NULL, `timeRegistration` VARCHAR(8) NOT NULL)', null, function(){});
			
			
			transaction.executeSql('CREATE TABLE IF NOT EXISTS `lessons` (`lesson` INT, `min` INT, `max` INT)', null, function(){});
			transaction.executeSql('SELECT * FROM `lessons`', null, function(transaction, results){
				let length = results.rows.length;
				if(length == 0){
					transaction.executeSql('INSERT INTO `lessons` (`lesson`, `min`, `max`) VALUES (1, 1, 9)', null);
					transaction.executeSql('INSERT INTO `lessons` (`lesson`, `min`, `max`) VALUES (2, 10, 24)', null);
					transaction.executeSql('INSERT INTO `lessons` (`lesson`, `min`, `max`) VALUES (3, 25, 40)', null);
					transaction.executeSql('INSERT INTO `lessons` (`lesson`, `min`, `max`) VALUES (4, 41, 60)', null);
					transaction.executeSql('INSERT INTO `lessons` (`lesson`, `min`, `max`) VALUES (5, 61, 77)', null);
					transaction.executeSql('INSERT INTO `lessons` (`lesson`, `min`, `max`) VALUES (6, 78, 94)', null);
					transaction.executeSql('INSERT INTO `lessons` (`lesson`, `min`, `max`) VALUES (7, 95, 111)', null);
					transaction.executeSql('INSERT INTO `lessons` (`lesson`, `min`, `max`) VALUES (8, 112, 126)', null);
					transaction.executeSql('INSERT INTO `lessons` (`lesson`, `min`, `max`) VALUES (9, 127, 145)', null);
					transaction.executeSql('INSERT INTO `lessons` (`lesson`, `min`, `max`) VALUES (10, 146, 163)', null);
					transaction.executeSql('INSERT INTO `lessons` (`lesson`, `min`, `max`) VALUES (11, 164, 177)', null);
					transaction.executeSql('INSERT INTO `lessons` (`lesson`, `min`, `max`) VALUES (12, 178, 191)', null);
				}
			});
			transaction.executeSql('CREATE TABLE IF NOT EXISTS `dictations` (`dictation` INT, `min` INT, `max` INT)', null, function(){});
			transaction.executeSql('SELECT * FROM `dictations`', null, function(transaction, results){
				let length = results.rows.length;
				if(length == 0){
					transaction.executeSql('INSERT INTO `dictations` (`dictation`, `min`, `max`) VALUES (1, 1, 1)', null);
					transaction.executeSql('INSERT INTO `dictations` (`dictation`, `min`, `max`) VALUES (2, 2, 5)', null);
					transaction.executeSql('INSERT INTO `dictations` (`dictation`, `min`, `max`) VALUES (3, 6, 21)', null);
					transaction.executeSql('INSERT INTO `dictations` (`dictation`, `min`, `max`) VALUES (4, 22, 35)', null);
					transaction.executeSql('INSERT INTO `dictations` (`dictation`, `min`, `max`) VALUES (5, 36, 48)', null);
					transaction.executeSql('INSERT INTO `dictations` (`dictation`, `min`, `max`) VALUES (6, 49, 60)', null);
					transaction.executeSql('INSERT INTO `dictations` (`dictation`, `min`, `max`) VALUES (7, 61, 73)', null);
					transaction.executeSql('INSERT INTO `dictations` (`dictation`, `min`, `max`) VALUES (8, 74, 83)', null);
					transaction.executeSql('INSERT INTO `dictations` (`dictation`, `min`, `max`) VALUES (9, 84, 99)', null);
					transaction.executeSql('INSERT INTO `dictations` (`dictation`, `min`, `max`) VALUES (10, 100, 114)', null);
					transaction.executeSql('INSERT INTO `dictations` (`dictation`, `min`, `max`) VALUES (11, 115, 122)', null);
					transaction.executeSql('INSERT INTO `dictations` (`dictation`, `min`, `max`) VALUES (12, 123, 130)', null);
				}
			});
			
			transaction.executeSql('CREATE TABLE IF NOT EXISTS `dictation` (`lesson` INT, `dictation` TEXT)', null, function(){});
			transaction.executeSql('SELECT * FROM `dictation`', null, function(transaction, results){
				let length = results.rows.length;
				if(length == 0){					
					for(let c = 0; c < dictations.length; c++){
						transaction.executeSql('INSERT INTO `dictation` (`lesson`, `dictation`) VALUES (' + lessonDictations[c]+ ', "' + dictations[c] + '")', null);
					}
				}
			});
			transaction.executeSql('CREATE TABLE IF NOT EXISTS `questions` (`id` INT, `stage` INT, `minLesson` INT, `maxLesson` INT)', null, function(){});
			transaction.executeSql('SELECT * FROM `questions`', null, function(tx, results){
				let length = results.rows.length;
				if(length == 0){
					tx.executeSql('INSERT INTO `questions` (`id`, `stage`, `minLesson`, `maxLesson`) VALUES (1, 1, 1, 5)', null);
					
					tx.executeSql('INSERT INTO `questions` (`id`, `stage`, `minLesson`, `maxLesson`) VALUES (2, 2, 6, 9)', null);
					tx.executeSql('INSERT INTO `questions` (`id`, `stage`, `minLesson`, `maxLesson`) VALUES (3, 2, 10, 11)', null);
					tx.executeSql('INSERT INTO `questions` (`id`, `stage`, `minLesson`, `maxLesson`) VALUES (4, 2, 12, 13)', null);
					tx.executeSql('INSERT INTO `questions` (`id`, `stage`, `minLesson`, `maxLesson`) VALUES (5, 2, 14, 15)', null);
					
					tx.executeSql('INSERT INTO `questions` (`id`, `stage`, `minLesson`, `maxLesson`) VALUES (6, 3, 16, 17)', null);
					tx.executeSql('INSERT INTO `questions` (`id`, `stage`, `minLesson`, `maxLesson`) VALUES (7, 3, 18, 19)', null);
					tx.executeSql('INSERT INTO `questions` (`id`, `stage`, `minLesson`, `maxLesson`) VALUES (8, 3, 20, 21)', null);
					tx.executeSql('INSERT INTO `questions` (`id`, `stage`, `minLesson`, `maxLesson`) VALUES (9, 3, 22, 23)', null);
					tx.executeSql('INSERT INTO `questions` (`id`, `stage`, `minLesson`, `maxLesson`) VALUES (10, 3, 24, 25)', null);
					tx.executeSql('INSERT INTO `questions` (`id`, `stage`, `minLesson`, `maxLesson`) VALUES (11, 3, 26, 27)', null);
					tx.executeSql('INSERT INTO `questions` (`id`, `stage`, `minLesson`, `maxLesson`) VALUES (12, 3, 28, 29)', null);
					tx.executeSql('INSERT INTO `questions` (`id`, `stage`, `minLesson`, `maxLesson`) VALUES (13, 3, 30, 31)', null);
					
					tx.executeSql('INSERT INTO `questions` (`id`, `stage`, `minLesson`, `maxLesson`) VALUES (14, 4, 32, 33)', null);
					tx.executeSql('INSERT INTO `questions` (`id`, `stage`, `minLesson`, `maxLesson`) VALUES (15, 4, 34, 35)', null);
					tx.executeSql('INSERT INTO `questions` (`id`, `stage`, `minLesson`, `maxLesson`) VALUES (16, 4, 36, 37)', null);
					tx.executeSql('INSERT INTO `questions` (`id`, `stage`, `minLesson`, `maxLesson`) VALUES (17, 4, 38, 39)', null);
					tx.executeSql('INSERT INTO `questions` (`id`, `stage`, `minLesson`, `maxLesson`) VALUES (18, 4, 40, 41)', null);
					tx.executeSql('INSERT INTO `questions` (`id`, `stage`, `minLesson`, `maxLesson`) VALUES (19, 4, 42, 43)', null);
					tx.executeSql('INSERT INTO `questions` (`id`, `stage`, `minLesson`, `maxLesson`) VALUES (20, 4, 44, 45)', null);
					tx.executeSql('INSERT INTO `questions` (`id`, `stage`, `minLesson`, `maxLesson`) VALUES (21, 4, 46, 47)', null);
					tx.executeSql('INSERT INTO `questions` (`id`, `stage`, `minLesson`, `maxLesson`) VALUES (22, 4, 48, 49)', null);
					tx.executeSql('INSERT INTO `questions` (`id`, `stage`, `minLesson`, `maxLesson`) VALUES (23, 4, 50, 51)', null);
					
					tx.executeSql('INSERT INTO `questions` (`id`, `stage`, `minLesson`, `maxLesson`) VALUES (24, 5, 52, 53)', null);
					tx.executeSql('INSERT INTO `questions` (`id`, `stage`, `minLesson`, `maxLesson`) VALUES (25, 5, 54, 55)', null);
					tx.executeSql('INSERT INTO `questions` (`id`, `stage`, `minLesson`, `maxLesson`) VALUES (26, 5, 56, 57)', null);
					tx.executeSql('INSERT INTO `questions` (`id`, `stage`, `minLesson`, `maxLesson`) VALUES (27, 5, 58, 59)', null);
					tx.executeSql('INSERT INTO `questions` (`id`, `stage`, `minLesson`, `maxLesson`) VALUES (28, 5, 60, 61)', null);
					tx.executeSql('INSERT INTO `questions` (`id`, `stage`, `minLesson`, `maxLesson`) VALUES (29, 5, 62, 63)', null);
					tx.executeSql('INSERT INTO `questions` (`id`, `stage`, `minLesson`, `maxLesson`) VALUES (30, 5, 64, 65)', null);
					tx.executeSql('INSERT INTO `questions` (`id`, `stage`, `minLesson`, `maxLesson`) VALUES (31, 5, 66, 67)', null);
					
					tx.executeSql('INSERT INTO `questions` (`id`, `stage`, `minLesson`, `maxLesson`) VALUES (32, 6, 68, 69)', null);
					tx.executeSql('INSERT INTO `questions` (`id`, `stage`, `minLesson`, `maxLesson`) VALUES (33, 6, 70, 71)', null);
					tx.executeSql('INSERT INTO `questions` (`id`, `stage`, `minLesson`, `maxLesson`) VALUES (34, 6, 72, 73)', null);
					tx.executeSql('INSERT INTO `questions` (`id`, `stage`, `minLesson`, `maxLesson`) VALUES (35, 6, 74, 75)', null);
					tx.executeSql('INSERT INTO `questions` (`id`, `stage`, `minLesson`, `maxLesson`) VALUES (36, 6, 76, 77)', null);
					tx.executeSql('INSERT INTO `questions` (`id`, `stage`, `minLesson`, `maxLesson`) VALUES (37, 6, 78, 79)', null);
					tx.executeSql('INSERT INTO `questions` (`id`, `stage`, `minLesson`, `maxLesson`) VALUES (38, 6, 80, 81)', null);
					tx.executeSql('INSERT INTO `questions` (`id`, `stage`, `minLesson`, `maxLesson`) VALUES (39, 6, 82, 83)', null);
					tx.executeSql('INSERT INTO `questions` (`id`, `stage`, `minLesson`, `maxLesson`) VALUES (40, 6, 84, 85)', null);
					
					tx.executeSql('INSERT INTO `questions` (`id`, `stage`, `minLesson`, `maxLesson`) VALUES (41, 7, 86, 87)', null);
					tx.executeSql('INSERT INTO `questions` (`id`, `stage`, `minLesson`, `maxLesson`) VALUES (42, 7, 88, 89)', null);
					tx.executeSql('INSERT INTO `questions` (`id`, `stage`, `minLesson`, `maxLesson`) VALUES (43, 7, 90, 91)', null);
					tx.executeSql('INSERT INTO `questions` (`id`, `stage`, `minLesson`, `maxLesson`) VALUES (44, 7, 92, 93)', null);
					tx.executeSql('INSERT INTO `questions` (`id`, `stage`, `minLesson`, `maxLesson`) VALUES (45, 7, 94, 95)', null);
					tx.executeSql('INSERT INTO `questions` (`id`, `stage`, `minLesson`, `maxLesson`) VALUES (46, 7, 96, 97)', null);
					tx.executeSql('INSERT INTO `questions` (`id`, `stage`, `minLesson`, `maxLesson`) VALUES (47, 7, 98, 99)', null);
					tx.executeSql('INSERT INTO `questions` (`id`, `stage`, `minLesson`, `maxLesson`) VALUES (48, 7, 100, 101)', null);
					
					tx.executeSql('INSERT INTO `questions` (`id`, `stage`, `minLesson`, `maxLesson`) VALUES (49, 8, 102, 103)', null);
					tx.executeSql('INSERT INTO `questions` (`id`, `stage`, `minLesson`, `maxLesson`) VALUES (50, 8, 104, 105)', null);
					tx.executeSql('INSERT INTO `questions` (`id`, `stage`, `minLesson`, `maxLesson`) VALUES (51, 8, 106, 107)', null);
					tx.executeSql('INSERT INTO `questions` (`id`, `stage`, `minLesson`, `maxLesson`) VALUES (52, 8, 108, 109)', null);
					tx.executeSql('INSERT INTO `questions` (`id`, `stage`, `minLesson`, `maxLesson`) VALUES (53, 8, 110, 111)', null);
					tx.executeSql('INSERT INTO `questions` (`id`, `stage`, `minLesson`, `maxLesson`) VALUES (54, 8, 112, 113)', null);
					tx.executeSql('INSERT INTO `questions` (`id`, `stage`, `minLesson`, `maxLesson`) VALUES (55, 8, 114, 115)', null);
					tx.executeSql('INSERT INTO `questions` (`id`, `stage`, `minLesson`, `maxLesson`) VALUES (56, 8, 116, 117)', null);
					
					tx.executeSql('INSERT INTO `questions` (`id`, `stage`, `minLesson`, `maxLesson`) VALUES (57, 9, 118, 119)', null);
					tx.executeSql('INSERT INTO `questions` (`id`, `stage`, `minLesson`, `maxLesson`) VALUES (58, 9, 120, 121)', null);
					tx.executeSql('INSERT INTO `questions` (`id`, `stage`, `minLesson`, `maxLesson`) VALUES (59, 9, 122, 123)', null);
					tx.executeSql('INSERT INTO `questions` (`id`, `stage`, `minLesson`, `maxLesson`) VALUES (60, 9, 124, 125)', null);
					tx.executeSql('INSERT INTO `questions` (`id`, `stage`, `minLesson`, `maxLesson`) VALUES (61, 9, 126, 127)', null);
					tx.executeSql('INSERT INTO `questions` (`id`, `stage`, `minLesson`, `maxLesson`) VALUES (62, 9, 128, 129)', null);
					tx.executeSql('INSERT INTO `questions` (`id`, `stage`, `minLesson`, `maxLesson`) VALUES (63, 9, 130, 131)', null);
					tx.executeSql('INSERT INTO `questions` (`id`, `stage`, `minLesson`, `maxLesson`) VALUES (64, 9, 132, 133)', null);
					tx.executeSql('INSERT INTO `questions` (`id`, `stage`, `minLesson`, `maxLesson`) VALUES (65, 9, 134, 135)', null);
					
					tx.executeSql('INSERT INTO `questions` (`id`, `stage`, `minLesson`, `maxLesson`) VALUES (66, 10, 136, 137)', null);
					tx.executeSql('INSERT INTO `questions` (`id`, `stage`, `minLesson`, `maxLesson`) VALUES (67, 10, 138, 139)', null);
					tx.executeSql('INSERT INTO `questions` (`id`, `stage`, `minLesson`, `maxLesson`) VALUES (68, 10, 140, 141)', null);
					tx.executeSql('INSERT INTO `questions` (`id`, `stage`, `minLesson`, `maxLesson`) VALUES (69, 10, 142, 143)', null);
					tx.executeSql('INSERT INTO `questions` (`id`, `stage`, `minLesson`, `maxLesson`) VALUES (70, 10, 144, 145)', null);
					tx.executeSql('INSERT INTO `questions` (`id`, `stage`, `minLesson`, `maxLesson`) VALUES (71, 10, 146, 147)', null);
					tx.executeSql('INSERT INTO `questions` (`id`, `stage`, `minLesson`, `maxLesson`) VALUES (72, 10, 148, 149)', null);
					tx.executeSql('INSERT INTO `questions` (`id`, `stage`, `minLesson`, `maxLesson`) VALUES (73, 10, 150, 151)', null);
					tx.executeSql('INSERT INTO `questions` (`id`, `stage`, `minLesson`, `maxLesson`) VALUES (74, 10, 152, 153)', null);
					tx.executeSql('INSERT INTO `questions` (`id`, `stage`, `minLesson`, `maxLesson`) VALUES (75, 10, 154, 155)', null);
					tx.executeSql('INSERT INTO `questions` (`id`, `stage`, `minLesson`, `maxLesson`) VALUES (76, 10, 156, 157)', null);
					tx.executeSql('INSERT INTO `questions` (`id`, `stage`, `minLesson`, `maxLesson`) VALUES (77, 10, 158, 159)', null);
					tx.executeSql('INSERT INTO `questions` (`id`, `stage`, `minLesson`, `maxLesson`) VALUES (78, 10, 160, 161)', null);
					tx.executeSql('INSERT INTO `questions` (`id`, `stage`, `minLesson`, `maxLesson`) VALUES (79, 10, 162, 163)', null);
				}
			});
			/////////////////////////////////////////////////       EMOJI      ////////////////////////////////////////////////
			transaction.executeSql('CREATE TABLE IF NOT EXISTS `faceEmoji` (`code` VARCHAR(15))', null, function(){});
			transaction.executeSql('SELECT * FROM `faceEmoji`', null, function(transaction, results){
				var length = results.rows.length;
				var emojis = ["&#128512;", "&#128513;", "&#128514;", "&#128515;", "&#128516;", "&#128517;", "&#128518;", "&#128519;", "&#128520;", "&#128521;", "&#128522;", "&#128523;", "&#128524;", "&#128525;", "&#128526;", "&#128527;", "&#128528;", "&#128529;", "&#128530;", "&#128531;", "&#128532;", "&#128533;", "&#128534;", "&#128535;", "&#128536;", "&#128537;", "&#128538;", "&#128539;", "&#128540;", "&#128541;", "&#128542;", "&#128543;", "&#128544;", "&#128545;", "&#128546;", "&#128547;", "&#128548;", "&#128549;", "&#128550;", "&#128551;", "&#128552;", "&#128553;", "&#128554;", "&#128555;", "&#128556;", "&#128557;", "&#128558;", "&#128559;", "&#128560;", "&#128561;", "&#128562;", "&#128563;", "&#128564;", "&#128565;", "&#128566;", "&#128567;", "&#128568;", "&#128569;", "&#128570;", "&#128571;", "&#128572;", "&#128573;", "&#128574;", "&#128575;", "&#128576;", "&#128577;", "&#128578;", "&#128579;", "&#128580;", "&#129296;", "&#129297;", "&#129298;", "&#129299;", "&#129300;", "&#129301;", "&#129312;", "&#129313;", "&#129314;", "&#129315;", "&#129316;", "&#129317;", "&#129318;", "&#129319;", "&#129320;", "&#129321;", "&#129322;", "&#129323;", "&#129324;", "&#129325;", "&#129326;", "&#129327;", "&#129488;", "&#128068;", "&#128069;", "&#129302;", "&#128121;", "&#128122;", "&#128123;", "&#128125;", "&#128126;", "&#128127;", "&#128128;", "&#128584;", "&#128585;", "&#128586;", "&#128106;", "&#128107;", "&#128108;", "&#128109;", "&#128111;", "&#128143;", "&#128145;"];
				if(length == 0){
					for(var s = 0; s < emojis.length; s++){
						transaction.executeSql('INSERT INTO `faceEmoji` (`code`) VALUES ("'+emojis[s]+'")', null);
					}
				}
			});
			transaction.executeSql('CREATE TABLE IF NOT EXISTS `bodyEmoji` (`code` VARCHAR(15))', null, function(){});
			transaction.executeSql('SELECT * FROM `bodyEmoji`', null, function(transaction, results){
				var length = results.rows.length;
				var emoji = ["&#9757;", "&#9994;", "&#9995;", "&#9996;", "&#9997;", "&#128070;", "&#128071;", "&#128072;", "&#128073;", "&#128074;", "&#128075;", "&#128076;", "&#128077;", "&#128078;", "&#128079;", "&#128080;", "&#128400;", "&#128405;", "&#128406;", "&#129304;", "&#129305;", "&#129306;", "&#129307;", "&#129308;", "&#129309;", "&#129310;", "&#129311;", "&#129330;", "&#128066;", "&#128067;", "&#128170;", "&#9977;", "&#127877;", "&#127938;", "&#127939;", "&#127940;", "&#127943;", "&#127946;", "&#127947;", "&#127948;", "&#128102;", "&#128103;", "&#128104;", "&#128105;", "&#128110;", "&#128112;", "&#128113;", "&#128114;", "&#128115;", "&#128116;", "&#128117;", "&#128118;", "&#128119;", "&#128120;", "&#128124;", "&#128129;", "&#128130;", "&#128131;", "&#128133;", "&#128134;", "&#128135;", "&#128581;", "&#128582;", "&#128583;", "&#128587;", "&#128589;", "&#128590;", "&#128591;", "&#128675;", "&#128692;", "&#128693;", "&#128694;", "&#128704;", "&#128716;", "&#129318;", "&#129328;", "&#129329;", "&#129331;", "&#129332;", "&#129333;", "&#129334;", "&#129335;", "&#129336;", "&#129337;", "&#129341;", "&#129342;", "&#129489;", "&#129490;", "&#129491;", "&#129492;", "&#129493;", "&#129494;", "&#129495;", "&#129496;", "&#129497;", "&#129498;", "&#129500;", "&#129501;"];
				if(length == 0){
					for(var s = 0; s < emoji.length; s++){
						transaction.executeSql('INSERT INTO `bodyEmoji` (`code`) VALUES ("'+emoji[s]+'")', null);
					}
				}
			});
			transaction.executeSql('CREATE TABLE IF NOT EXISTS `heartEmoji` (`code` VARCHAR(15))', null, function(){});
			transaction.executeSql('SELECT * FROM `heartEmoji`', null, function(transaction, results){
				var length = results.rows.length;
				var emoji = ["&#10083;", "&#10084;", "&#128147;", "&#128148;", "&#128149;", "&#128150;", "&#128151;", "&#128152;", "&#128153;", "&#128154;", "&#128155;", "&#128156;", "&#128157;", "&#128158;", "&#128159;"];
				if(length == 0){
					for(var s = 0; s < emoji.length; s++){
						transaction.executeSql('INSERT INTO `heartEmoji` (`code`) VALUES ("'+emoji[s]+'")', null);
					}
				}
			});
			transaction.executeSql('CREATE TABLE IF NOT EXISTS `animalEmoji` (`code` VARCHAR(15))', null, function(){});
			transaction.executeSql('SELECT * FROM `animalEmoji`', null, function(transaction, results){
				var length = results.rows.length;
				var emoji = ["&#128062;", "&#128000;", "&#128001;", "&#128002;", "&#128003;", "&#128004;", "&#128005;", "&#128006;", "&#128007;", "&#128008;", "&#128009;", "&#128010;", "&#128011;", "&#128012;", "&#128013;", "&#128014;", "&#128015;", "&#128016;", "&#128017;", "&#128018;", "&#128019;", "&#128020;", "&#128021;", "&#128022;", "&#128023;", "&#128024;", "&#128025;", "&#128026;", "&#128027;", "&#128028;", "&#128029;", "&#128030;", "&#128031;", "&#128032;", "&#128033;", "&#128034;", "&#128035;", "&#128036;", "&#128037;", "&#128038;", "&#128039;", "&#128040;", "&#128041;", "&#128042;", "&#128043;", "&#128044;", "&#128045;", "&#128046;", "&#128047;", "&#128048;", "&#128049;", "&#128050;", "&#128051;", "&#128052;", "&#128053;", "&#128054;", "&#128055;", "&#128056;", "&#128057;", "&#128058;", "&#128059;", "&#128060;", "&#128061;", "&#129408;", "&#129409;", "&#129410;", "&#129411;", "&#129412;", "&#129413;", "&#129414;", "&#129415;", "&#129416;", "&#129417;", "&#129418;", "&#129419;", "&#129420;", "&#129421;", "&#129422;", "&#129423;", "&#129424;", "&#129425;", "&#129426;", "&#129427;", "&#129428;", "&#129429;", "&#129430;", "&#129431;"];
				if(length == 0){
					for(var s = 0; s < emoji.length; s++){
						transaction.executeSql('INSERT INTO `animalEmoji` (`code`) VALUES ("'+emoji[s]+'")', null);
					}
				}
			});
			transaction.executeSql('CREATE TABLE IF NOT EXISTS `treeEmoji` (`code` VARCHAR(15))', null, function(){});
			transaction.executeSql('SELECT * FROM `treeEmoji`', null, function(transaction, results){
				var length = results.rows.length;
				var emoji = ["&#127792;", "&#127793;", "&#127794;", "&#127795;", "&#127796;", "&#127797;", "&#127798;", "&#127799;", "&#127801;", "&#127802;", "&#127803;", "&#127804;", "&#127805;", "&#127806;", "&#127807;", "&#127808;", "&#127809;", "&#127810;", "&#127811;", "&#127812;", "&#127813;", "&#127814;", "&#127815;", "&#127816;", "&#127817;", "&#127818;", "&#127819;", "&#127820;", "&#127821;", "&#127822;", "&#127823;", "&#127824;", "&#127825;", "&#127826;", "&#127827;", "&#129344;", "&#129361;", "&#129362;", "&#129365;", "&#129372;", "&#129373", "&#129381;"];
				if(length == 0){
					for(var s = 0; s < emoji.length; s++){
						transaction.executeSql('INSERT INTO `treeEmoji` (`code`) VALUES ("'+emoji[s]+'")', null);
					}
				}
			});
			transaction.executeSql('CREATE TABLE IF NOT EXISTS `foodEmoji` (`code` VARCHAR(15))', null, function(){});
			transaction.executeSql('SELECT * FROM `foodEmoji`', null, function(transaction, results){
				var length = results.rows.length;
				var emoji = ["&#127789;", "&#127790;", "&#127791;", "&#127828;", "&#127829;", "&#127830;", "&#127831;", "&#127832;", "&#127833;", "&#127834;", "&#127835;", "&#127836;", "&#127837;", "&#127838;", "&#127839;", "&#127840;", "&#127841;", "&#127842;", "&#127843;", "&#127844;", "&#127845;", "&#127846;", "&#127847;", "&#127848;", "&#127849;", "&#127850;", "&#127851;", "&#127852;", "&#127853;", "&#127854;", "&#127855;", "&#127856;", "&#127857;", "&#127858;", "&#127859;", "&#127860;", "&#127861;", "&#127862;", "&#127863;", "&#127864;", "&#127865;", "&#127866;", "&#127867;", "&#127868;", "&#127869;", "&#127870;", "&#127871;", "&#127874;", "&#129366;", "&#129367;", "&#129368;", "&#129369;", "&#129370;", "&#129371;", "&#129374;", "&#129375;", "&#129376;", "&#129377;", "&#129378;", "&#129379;", "&#129380;", "&#129382;", "&#129383;", "&#129384;", "&#129385;", "&#129386;", "&#129387;", "&#129472;"];
				if(length == 0){
					for(var s = 0; s < emoji.length; s++){
						transaction.executeSql('INSERT INTO `foodEmoji` (`code`) VALUES ("'+emoji[s]+'")', null);
					}
				}
			});
			transaction.executeSql('CREATE TABLE IF NOT EXISTS `transportEmoji` (`code` VARCHAR(15))', null, function(){});
			transaction.executeSql('SELECT * FROM `transportEmoji`', null, function(transaction, results){
				var length = results.rows.length;
				var emoji = ["&#128640;", "&#128641;", "&#128642;", "&#128643;", "&#128644;", "&#128645;", "&#128646;", "&#128647;", "&#128648;", "&#128649;", "&#128650;", "&#128651;", "&#128652;", "&#128653;", "&#128654;", "&#128655;", "&#128656;", "&#128657;", "&#128658;", "&#128659;", "&#128660;", "&#128661;", "&#128662;", "&#128663;", "&#128664;", "&#128665;", "&#128666;", "&#128667;", "&#128668;", "&#128669;", "&#128670;", "&#128671;", "&#128672;", "&#128673;", "&#128674;", "&#128675;", "&#128676;", "&#128677;", "&#128678;", "&#128679;", "&#128680;", "&#128681;", "&#128682;", "&#128683;", "&#128690;", "&#128721;", "&#128747;", "&#128748;", "&#128756;", "&#128757;", "&#128758;", "&#128759;", "&#128760;"];
				if(length == 0){
					for(var s = 0; s < emoji.length; s++){
						transaction.executeSql('INSERT INTO `transportEmoji` (`code`) VALUES ("'+emoji[s]+'")', null);
					}
				}
			});
			transaction.executeSql('CREATE TABLE IF NOT EXISTS `clothesEmoji` (`code` VARCHAR(15))', null, function(){});
			transaction.executeSql('SELECT * FROM `clothesEmoji`', null, function(transaction, results){
				var length = results.rows.length;
				var emoji = ["&#128082;", "&#128083;", "&#128084;", "&#128085;", "&#128086;", "&#128087;", "&#128088;", "&#128089;", "&#128090;", "&#128091;", "&#128092;", "&#128093;", "&#128094;", "&#128095;", "&#128096;", "&#128097;", "&#128098;", "&#128099;", "&#129509;", "&#129510;"];
				if(length == 0){
					for(var s = 0; s < emoji.length; s++){
						transaction.executeSql('INSERT INTO `clothesEmoji` (`code`) VALUES ("'+emoji[s]+'")', null);
					}
				}
			});
			///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
			transaction.executeSql('CREATE TABLE IF NOT EXISTS `stories` (`id` INT, `nameEnglish` VARCHAR(200), `namePortuguese` VARCHAR(200), `textEnglish` TEXT, `textPortuguese` TEXT)', null, function(){});
			transaction.executeSql('SELECT * FROM `stories`', null, function(transaction, results){
				var length = results.rows.length;		
				
				if(length == 0){
					for(var s = 0; s < stories.length; s++){
						let id = s + 1;
						let inglesTitle = stories[s][0];
						let portugueseTitle = stories[s][1];
						let inglesText = stories[s][2];
						let portugueseText = stories[s][3];
						transaction.executeSql('INSERT INTO `stories` (`id`, `nameEnglish`, `namePortuguese`, `textEnglish`, `textPortuguese`) VALUES (' + id + ', "' + inglesTitle + '", "' + portugueseTitle + '", "' + dictationsEnglish[s] + '", "' + dictationsPortuguese[s] + '")', null);
					}
				}
			});
			///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
			transaction.executeSql('CREATE TABLE IF NOT EXISTS `words` (`inPortuguese` TEXT, `inEnglish` TEXT)', null, function(){});
			transaction.executeSql('SELECT * FROM `words`', null, function(tx, results){
				let length = results.rows.length;
				if(length == 0){
					for(let c = 0; c < wordsInEnglish.length; c++){
						tx.executeSql('INSERT INTO `words` (`inPortuguese`, `inEnglish`) VALUES ("'+wordsInPortuguese[c]+'", "'+wordsInEnglish[c]+'")');
					}
				}
			});
			///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
			for(let c = 1; c <= lengthQuestions; c++){
				transaction.executeSql('CREATE TABLE IF NOT EXISTS `revision'+c+'` (`id` INT, `stage` INT, `lessons` VARCHAR(20), `question1` TEXT, `question2` TEXT, `question3` TEXT,`question4` TEXT, `question5` TEXT, `question6` TEXT, `question7` TEXT,`question8` TEXT, `question9` TEXT, `question10` TEXT, `question11` TEXT, `question12` TEXT, `question13` TEXT, `question14` TEXT, `question15` TEXT, `question16` TEXT, `question17` TEXT, `question18` TEXT, `question19` TEXT, `question20` TEXT, `answer1` TEXT, `answer2` TEXT, `answer3` TEXT, `answer4` TEXT, `answer5` TEXT, `answer6` TEXT, `answer7` TEXT, `answer8` TEXT, `answer9` TEXT, `answer10` TEXT, `answer11` TEXT, `answer12` TEXT, `answer13` TEXT, `answer14` TEXT, `answer15` TEXT, `answer16` TEXT, `answer17` TEXT, `answer18` TEXT, `answer19` TEXT, `answer20` TEXT)', null, function(){});
				transaction.executeSql('SELECT * FROM `revision'+ c +'`', null, function(transaction, results){
					let length = results.rows.length;
					if(length == 0){
						transaction.executeSql('INSERT INTO `revision'+ c +'` (`id`, `stage`, `lessons`) VALUES ('+ c +', '+ questionsList[c][0] +', "'+ questionsList[c][1] +'")');
					}
					else{
						for(let i = 0; i < length; i++){
							let item = results.rows.item(i);
							if(item.question1 == null){
								for(let r = 1; r <= 20; r++){
									let question = window["question"+item.id+"Q"][(r - 1)];
									let answer = window["question"+item.id+"A"][(r - 1)];
									transaction.executeSql('UPDATE `revision'+item.id+'` SET `question'+r+'`="'+question+'", `answer'+r+'`="'+answer+'"')
								}
							}
						}
					}
				});
			}
			///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
		});
		
	}
}
bd();