var modeTranslation = 1;

$("document").ready(function(){
	localStorage.setItem("pageNow", "translater");
		
	$("body div#menu table tr td#icon").click(function(){
		goToPage("home");
	});
	
	$("body div#content form#translate label table td#field #word").focus(function(){
		$("body div#content form#translate label table").css("border", "1px solid #f5f6fa");
	});
	
	$("body div#content form#translate").submit(function(e){
		e.preventDefault();
		let text = $("body div#content form#translate label table td#field #word").val();
		if(text.length == 0){
			$("body div#content form#translate label table").css("border", "1px solid red");
			$("body div#content div#results").css("display", "none");
			$("body div#content div#results table#original").html("");
			$("body div#content div#results table#translated").html("");
		}
		else{
			if(modeTranslation == 1){
				dialog.startLoader("Procurando palavra ou expressão...");
				database.transaction(function(transaction){
					transaction.executeSql('SELECT * FROM `words` WHERE `inEnglish` LIKE "%'+text+'%"', null, function(tx, results){
						let length = results.rows.length;
						if(length != 0){
							$("body div#content div#results table#original").html("");
							$("body div#content div#results table#translated").html("");
							for(let c = 0; c < length; c++){
								let item = results.rows.item(c);
								$("body div#content div#results table#original").append('<tr><td class="text"><p>'+item.inEnglish+'<p></td><td class="icon"><i class="fa fa-volume-up waves-effect" onClick="speakInEnglish(`'+item.inEnglish+'`);"></i></td></tr>');
								$("body div#content div#results table#translated").append('<tr><td class="text"><p>'+item.inPortuguese+'<p></td><td class="icon"><i class="fa fa-volume-up waves-effect" onClick="speakInPortuguese(`'+item.inPortuguese+'`);"></i></td></tr>');
							}
							$("body div#content div#results").css("display", "block");
							dialog.stopLoader();
						}
						else{
							$("body div#content div#results").css("display", "none");
							$("body div#content div#results table#original").html("");
							$("body div#content div#results table#translated").html("");
							dialog.stopLoader();
							dialog.alert("Nenhuma palavra ou expressão encontrado.");
						}
					});
				});
			}
			else{
				dialog.startLoader("Procurando palavra ou expressão...");
				database.transaction(function(transaction){
					transaction.executeSql('SELECT * FROM `words` WHERE `inPortuguese` LIKE "%'+text+'%"', null, function(tx, results){
						let length = results.rows.length;
						if(length != 0){
							$("body div#content div#results table#original").html("");
							$("body div#content div#results table#translated").html("");
							for(let c = 0; c < length; c++){
								let item = results.rows.item(c);
								$("body div#content div#results table#original").append('<tr><td class="text"><p>'+item.inPortuguese+'<p></td><td class="icon"><i class="fa fa-volume-up waves-effect" onClick="speakInPortuguese(`'+item.inPortuguese+'`);"></i></td></tr>');
								$("body div#content div#results table#translated").append('<tr><td class="text"><p>'+item.inEnglish+'<p></td><td class="icon"><i class="fa fa-volume-up waves-effect" onClick="speakInEnglish(`'+item.inEnglish+'`);"></i></td></tr>');
							}
							$("body div#content div#results").css("display", "block");
							dialog.stopLoader();
						}
						else{
							$("body div#content div#results").css("display", "none");
							$("body div#content div#results table#original").html("");
							$("body div#content div#results table#translated").html("");
							dialog.stopLoader();
							dialog.alert("Nenhuma palavra ou expressão encontrado.");
						}
					});
				});
			}
		}
	});
	$("body div#content form#translate label table td#icon").click(function(){
		permissions.hasPermission(permissions.RECORD_AUDIO, function(status){
			if(status.hasPermission){
				if(modeTranslation == 1){
					window.plugins.speechRecognition.startListening(function(results){
						$("body div#content form#translate label table td#field #word").val(results[0]);
						$("body div#content button#search").click();
					}, function(){
						dialog.alert("Houve algum erro, tente novamente.");
					}, {
						language: "pt-BR",
						matches: 5,
						prompt: "Fale algo em Inglês",
						showPopup: true,
					});
				}
				else{				
					window.plugins.speechRecognition.startListening(function(results){
						$("body div#content form#translate label table td#field #word").val(results[0]);
						$("body div#content button#search").click();
						$("body div#content form#translate").submit();
					}, function(){
						dialog.alert("Houve algum erro, tente novamente.");
					}, {
						language: "pt-BR",
						matches: 5,
						prompt: "Fale algo em Português",
						showPopup: true,
					});
				}
			}
			else{
				permissions.requestPermission(permissions.RECORD_AUDIO, function(status){
					if(status.hasPermission){
						if(modeTranslation == 1){
							window.plugins.speechRecognition.startListening(function(results){
								$("body div#content form#translate label table td#field #word").val(results[0]);
								$("body div#content button#search").click();
							}, function(){
								dialog.alert("Houve algum erro, tente novamente.");
							}, {
								language: "pt-BR",
								matches: 5,
								prompt: "Fale algo em Inglês",
								showPopup: true,
							});
						}
						else{				
							window.plugins.speechRecognition.startListening(function(results){
								$("body div#content form#translate label table td#field #word").val(results[0]);
								$("body div#content button#search").click();
							}, function(){
								dialog.alert("Houve algum erro, tente novamente.");
							}, {
								language: "pt-BR",
								matches: 5,
								prompt: "Fale algo em Português",
								showPopup: true,
							});
						}
					}
					else{
						dialog.alert("Aceite a permissão para poder utilizar esse recurso.");
					}
				}, function(){
					dialog.alert("Aceite a permissão para poder utilizar esse recurso.");
				});
			}
		});
	});
	
	$("body div#content table#options tr td#change").click(function(){
		if(modeTranslation == 1){
			modeTranslation = 2;
			$("body div#content table#options tr td#from").text("Português");
			$("body div#content table#options tr td#to").text("Inglês");
		}
		else{
			modeTranslation = 1;
			$("body div#content table#options tr td#from").text("Inglês");
			$("body div#content table#options tr td#to").text("Português");
		}
	});
	
	$("body div#content button#search").click(function(){
		$("body div#content form#translate").submit();
	});
});

function speakInEnglish(text){
	TTS.speak({
		text: text,
		locale: "en-US",
		rate: 0.9
	}, function(){}, function(reason){
		dialog.alert("Houve algum erro: " + reason);
	});
}
function speakInPortuguese(text){
	TTS.speak({
		text: text,
		locale: "pt-BR",
		rate: 0.9
	}, function(){}, function(reason){
		dialog.alert("Houve algum erro: " + reason);
	});
}