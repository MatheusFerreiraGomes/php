var setDDD = 0;
var setDay = 0, setMonth = 0, setYear = 0;
$("document").ready(function(){
	localStorage.setItem("pageNow", "register");
	ConnectyCube.init(CREDENTIALS);
	
	if(sessionStorage.getItem("pageBack") != undefined){
		$("body div#register form#register label #fullName").val(sessionStorage.getItem("fullName"));
		$("body div#register form#register label #birthDate").val(sessionStorage.getItem("birthDate"));
		$("body div#register form#register label #phone").val(sessionStorage.getItem("phone"));
		$("body div#register form#register label #email").val(sessionStorage.getItem("email"));
		$("body div#register form#register label #password").val(sessionStorage.getItem("password"));
		sessionStorage.removeItem("fullName");
		sessionStorage.removeItem("birthDate");
		sessionStorage.removeItem("phone");
		sessionStorage.removeItem("email");
		sessionStorage.removeItem("password");
		sessionStorage.removeItem("pageBack");
	}
	
	$("body div#register form#register label input").focus(function(){
		$(this).css("border", "1px solid #f5f6fa");
	});
	
	$("body div#register form#register label #birthDate").keydown(function(){
		let val = $(this).val();
		if(val.length == 1) setDay = 1;
		if(val.length == 4) setMonth = 1;
	});
	$("body div#register form#register label #birthDate").keyup(function(){
		let val = $(this).val();
		if(setDay == 1 && val.length == 2){
			setDay = 0;
			$(this).val(val + "/");
		}
		if(setMonth == 1 && val.length == 5){
			setMonth = 0;
			$(this).val(val + "/");
		} 
		if(val.length >= 10){
			$("body div#register form#register label #phone").focus();
			$(this).val(val.substring(0, 10));
		}
	});
	
	$("body div#register form#register label #phone").focus(function(){
		if($(this).val().length == 0) $(this).val("(");
	});
	$("body div#register form#register label #phone").blur(function(){
		let val = $(this).val();
		if(val == "(") $(this).val("");
	});
	$("body div#register form#register label #phone").keydown(function(){
		let val = $(this).val();
		if(val.substring(0, 1) == "(" && val.length == 2 && val.substring(2, 3) != ") "){
			setDDD = 1;
		}
	});
	$("body div#register form#register label #phone").keyup(function(){
		let val = $(this).val();
		if(setDDD == 1 && val != "("){
			$(this).val(val + ") ");
			setDDD = 0;
		}
		else setDDD = 0;
		if(val.length == 0) $(this).val("(");
	});
	
	$("body div#register form#register").submit(function(e){
		e.preventDefault();
		
		let fullName = $("body div#register form#register label #fullName").val();
		let birthDate = $("body div#register form#register label #birthDate").val();
		let phone = $("body div#register form#register label #phone").val();
		let email = $("body div#register form#register label #email").val();
		let password = $("body div#register form#register label #password").val();
		
		let allMonths = [null, 31, 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31];
		
		let date = new Date();
		let timeCreated = ((date.getHours() <= 9) ? "0" + date.getHours() : date.getHours()) + ":" + ((date.getMinutes() <= 9) ? "0" + date.getMinutes() : date.getMinutes()) + ":" + ((date.getSeconds() <= 9) ? "0" + date.getSeconds() : date.getSeconds());
		
		let dateCreated = ((date.getDate() <= 9) ? "0" + date.getDate() : date.getDate()) + "/" + (((date.getMonth() + 1) <= 9) ? "0" + (date.getMonth() + 1) : (date.getMonth() + 1)) + "/" +  date.getFullYear();
		
		let dayE, monthE, yearE;
		
		dayE = date.getDate() + 3;
		monthE = (date.getMonth() + 1);
		yearE = date.getFullYear();
		
		if(dayE > allMonths[(date.getMonth() + 1)]){
			dayE = dayE - allMonths[(date.getMonth() + 1)];
			monthE = monthE + 1;
			if(monthE > 12){
				monthE = 1;
				yearE = yearE + 1;
			}
			
		}
		
		let dateExpire = ((dayE <= 9) ? "0" + dayE : dayE) + "/" + ((monthE <= 9) ? "0" + monthE : monthE) + "/" + yearE;
		let timeExpire = ((date.getHours() <= 9) ? "0" + date.getHours() : date.getHours()) + ":" + ((date.getMinutes() <= 9) ? "0" + date.getMinutes() : date.getMinutes()) + ":" + ((date.getSeconds() <= 9) ? "0" + date.getSeconds() : date.getSeconds());
		
		if(fullName.length == 0 || birthDate.length  == 0 || phone.length == 0 || email.length == 0 || password.length == 0){
			if(fullName.length == 0) $("body div#register form#register label #fullName").css("border", "1px solid red");
			if(birthDate.length == 0) $("body div#register form#register label #birthDate").css("border", "1px solid red");
			if(phone.length == 0) $("body div#register form#register label #phone").css("border", "1px solid red");
			if(email.length == 0) $("body div#register form#register label #email").css("border", "1px solid red");
			if(password.length == 0) $("body div#register form#register label #password").css("border", "1px solid red");
			M.toast({html: "Preencha todos os campos.", classes: "red", displayLength: 2000});
		}
		else if(fullName.split(" ").length <= 1){
			$("body div#register form#register label #fullName").css("border", "1px solid red");
			M.toast({html: "Preencha o nome completo com sobrenome.", classes: "red", displayLength: 2000});
		}
		else if(verifyBirth(birthDate) == false){
			$("body div#register form#register label #birthDate").css("border", "1px solid red");
			M.toast({html: "Data de nascimento inválida.", classes: "red", displayLength: 2000});
		}
		else if(verifyPhone(phone) == false){
			$("body div#register form#register label #phone").css("border", "1px solid red");
			M.toast({html: "Número de celular inválido.", classes: "red", displayLength: 2000});
		}
		else if(verifyEmail(email) == false){
			$("body div#register form#register label #email").css("border", "1px solid red");
			M.toast({html: "E-mail inválido.", classes: "red", displayLength: 2000});
		}
		else if(password.length < 8){
			$("body div#register form#register label #password").css("border", "1px solid red");
			M.toast({html: "Senha tem no mínimo 8 dígitos.", classes: "red", displayLength: 2000});
		}
		else{
			dialog.startLoader("Registrando...");
			let login = email.split("@")[0];
			let userRegister = {
				login: login,
				password: md5(password),
				email: email,
				full_name: fullName
			};
			ConnectyCube.createSession().then(function(session){
				ConnectyCube.users.signup(userRegister).then(function(sign){
					let userID = sign["user"]["id"];
					
					$.ajax({
						method: "POST", 
						url: urlSystem + "register.php",
						data: {
							fullName: fullName,
							birthDate: birthDate,
							phoneNumber: phone,
							email: email,
							password: md5(password),
							dateRegistration: dateCreated,
							timeRegistration: timeCreated,
							dateExpire: dateExpire,
							timeExpire: timeExpire,
							userID: userID
						}
					}).done(function(r){
						dialog.stopLoader();	
						if(r == 1){
							$("body div#register form#register label #phone").css("border", "1px solid red");
							dialog.alert("Já existe um usuário com esse número de celular.");
							ConnectyCube.users.delete(function(error){});
						}
						else if(r == 2){
							$("body div#register form#register label #email").css("border", "1px solid red");
							dialog.alert("Já existe um usuário com esse e-mail.");
							ConnectyCube.users.delete(function(error){});
						}
						else{
							sessionStorage.setItem("registerSuccess", 1);
							goToPage("login");
						}
					});
				}).catch(function(error){
					if(error["code"] == 422){
						$.ajax({
							method: "POST", 
							url: urlSystem + "register.php",
							data: {
								fullName: fullName,
								birthDate: birthDate,
								phoneNumber: phone,
								email: email,
								password: md5(password),
								dateRegistration: dateCreated,
								timeRegistration: timeCreated,
								dateExpire: dateExpire,
								timeExpire: timeExpire,
								userID: 11111
							}
						}).done(function(r){
							dialog.stopLoader();	
							if(r == 1){
								$("body div#register form#register label #phone").css("border", "1px solid red");
								dialog.alert("Já existe um usuário com esse número de celular.");
								ConnectyCube.users.delete(function(error){});
							}
							else if(r == 2){
								$("body div#register form#register label #email").css("border", "1px solid red");
								dialog.alert("Já existe um usuário com esse e-mail.");
								ConnectyCube.users.delete(function(error){});
							}
							else{
								sessionStorage.setItem("registerSuccess", 1);
								goToPage("login");
							}
						});
					}
					else{
						dialog.stopLoader();	
						dialog.alert("Houve algum erro, tente novamente.");
					}
				});
			});
		}
	});
	
	$("body div#register form#register p#login").click(function(){
		goToPage("login");
	});
	
});

function useTerms(){
	sessionStorage.setItem("fullName", $("body div#register form#register label #fullName").val());
	sessionStorage.setItem("birthDate", $("body div#register form#register label #birthDate").val());
	sessionStorage.setItem("phone", $("body div#register form#register label #phone").val());
	sessionStorage.setItem("email", $("body div#register form#register label #email").val());
	sessionStorage.setItem("password", $("body div#register form#register label #password").val());
	sessionStorage.setItem("pageBack", "register");
	goToPage("useTerms");
};
function privacy(){
	sessionStorage.setItem("fullName", $("body div#register form#register label #fullName").val());
	sessionStorage.setItem("birthDate", $("body div#register form#register label #birthDate").val());
	sessionStorage.setItem("phone", $("body div#register form#register label #phone").val());
	sessionStorage.setItem("email", $("body div#register form#register label #email").val());
	sessionStorage.setItem("password", $("body div#register form#register label #password").val());
	sessionStorage.setItem("pageBack", "register");
	goToPage("privacy");
};

function verifyEmail(email){
	let x = email;
	let atpos = x.indexOf("@");
	let dotpos = x.lastIndexOf(".");
	if (atpos<1 || dotpos<atpos+2 || dotpos+2>=x.length){
		return false;
	}
	else{
		return true;
	}
}
function verifyBirth(birth){
	let val = birth;
	let day, month, year;
	let date = new Date();
	day = val.substring(0, 2);
	month = val.substring(3, 5);
	year = val.substring(6, 10);
	if($.isNumeric(day) == true && $.isNumeric(month) == true && $.isNumeric(year) == true){
		if((day >= 1 && day <= 31) && (month >= 1 && month <= 12) && (year <= date.getFullYear())) return true;
		else return false;
	}
	else return false;
}
function verifyPhone(phone){
	if(/\([0-9]{2}\)[ ]?[0-9]{4,5}\-?[0-9]{4}$/.test(phone) == false) return false;
	else return true;
}