$("document").ready(function(){
	localStorage.setItem("pageNow", "index");
	
	if(localStorage.getItem("settingsKeyboard") == undefined) localStorage.setItem("settingsKeyboard", 0);
	if(localStorage.getItem("quantityDictation") == undefined) localStorage.setItem("quantityDictation", 3);
	if(localStorage.getItem("logged") != undefined){
		database.transaction(function(transaction){
			transaction.executeSql("SELECT * FROM `user` WHERE `rowid`=1", null, function(tx, results){
				let item = results.rows.item(0);
				let email = item.email;
				$.getJSON(urlSystem + "informations.php?email=" + email, function(r){
					if(r == 0){
						database.transaction(function(transaction){
							transaction.executeSql("DROP TABLE `user`", null, function(){
								localStorage.removeItem("logged");
							});
						});
					}
					else{
						database.transaction(function(transaction){
							transaction.executeSql("UPDATE `user` SET `email`='"+r["email"]+"', `fullName`='"+r["fullName"]+"', `birthDate`='"+r["birthDate"]+"', `phoneNumber`='"+r["phoneNumber"]+"', `picture`='"+r["picture"]+"', `dateRegistration`='"+r["dateRegistration"]+"', `timeRegistration`='"+r["timeRegistration"]+"' WHERE `rowid`=1");
						});
					}
				});
			});
		});
	}
	
	setTimeout(function(){
		if(localStorage.getItem("logged") != undefined) goToPage("home");
		else goToPage("options");
	}, 3500);
});