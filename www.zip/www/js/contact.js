$("document").ready(function(){
	localStorage.setItem("pageNow", "contact");
	$("body div#menu table tr td#icon").click(function(){
		goToPage("home");
	});
	$("body div#contact form#contact label .field").focus(function(){
		$(this).css("border", "1px solid #f5f6fa");
	});
	
	$("body div#contact form#contact").submit(function(e){
		e.preventDefault();
		let subject = $("body div#contact form#contact label #subject").val();
		let message = $("body div#contact form#contact label textarea#message").val();
		
		if(subject.length == 0 || message.length == 0){
			if(subject.length == 0) $("body div#contact form#contact label #subject").css("border", "1px solid red");
			if(message.length == 0) $("body div#contact form#contact label textarea#message").css("border", "1px solid red");
		}
		else{
			dialog.startLoader("Enviando mensagem...");
			database.transaction(function(transaction){
				transaction.executeSql("SELECT * FROM `user` WHERE `rowid`=1", null, function(transction, results){
					let item = results.rows.item(0);
					let email = item.email;
					let fullName = item.fullName;
					$.getJSON(urlSystem + "contact.php?fromEmail="+email+"&fullName="+fullName+"&subject="+subject+"&message="+message, function(results){
						dialog.stopLoader();
						if(results == 0){
							dialog.alert("Houve algum erro ao tentar enviar a mensagem, tente novamente.");
						}
						else{
							$("body div#contact form#contact label #subject").val("");
							$("body div#contact form#contact label textarea#message").val("");
							M.toast({html: "Mensagem enviada com sucesso!", classes: "green", displayLength: 4000});
						}
					}); 
				});
			});
		}
	});
});