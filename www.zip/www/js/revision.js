var questions, answers, questionsN, answersN, stage, speed;
$("document").ready(function(){
	localStorage.setItem("pageNow", "revision");
	$("body div#menu table tr td#icon").click(function(){
		sessionStorage.removeItem("revisionSelected");
		goToPage("home");
	});
	
	let revisionSelected = sessionStorage.getItem("revisionSelected");
	
	
	database.transaction(function(tx){
		tx.executeSql("SELECT * FROM `revision"+revisionSelected+"`", null, function(tx, results){
			let item = results.rows.item(0);
			
			questions = [null, formatted(item.question1), formatted(item.question2), formatted(item.question3), formatted(item.question4), formatted(item.question5), formatted(item.question6), formatted(item.question7), formatted(item.question8), formatted(item.question9), formatted(item.question10), formatted(item.question11), formatted(item.question12), formatted(item.question13), formatted(item.question14), formatted(item.question15), formatted(item.question16), formatted(item.question17), formatted(item.question18), formatted(item.question19), formatted(item.question20)];
			
			questionsN = [null, item.question1, item.question2, item.question3, item.question4, item.question5, item.question6, item.question7, item.question8, item.question9, item.question10, item.question11, item.question12, item.question13, item.question14, item.question15, item.question16, item.question17, item.question18, item.question19, item.question20];
			
			answers = [null, formatted(item.answer1), formatted(item.answer2), formatted(item.answer3), formatted(item.answer4), formatted(item.answer5), formatted(item.answer6), formatted(item.answer7), formatted(item.answer8), formatted(item.answer9), formatted(item.answer10), formatted(item.answer11), formatted(item.answer12), formatted(item.answer13), formatted(item.answer14), formatted(item.answer15), formatted(item.answer16), formatted(item.answer17), formatted(item.answer18), formatted(item.answer19), formatted(item.answer20)];
			
			answersN = [null, item.answer1, item.answer2, item.answer3, item.answer4, item.answer5, item.answer6, item.answer7, item.answer8, item.answer9, item.answer10, item.answer11, item.answer12, item.answer13, item.answer14, item.answer15, item.answer16, item.answer17, item.answer18, item.answer19, item.answer20];
			
			$("body div#question h5").text("Estágio "+ item.stage +" (Lições "+ item.lessons +")");
			$("body div#answer h5").text("Estágio "+ item.stage +" (Lições "+ item.lessons +")");
			stage = item.stage;
			
			if(stage >= 1 && stage <= 4) speed = 0.75;
			if(stage >= 5 && stage <= 8) speed = 0.85;
			if(stage >= 9 && stage <= 12) speed = 0.95;
			
			for(let c = 1; c <= 20; c++){
				$("body div#question div#itens").append('<p class="item" onClick="speek(`'+questionsN[c]+'`)">' + c + ') ' + questions[c] + '</p>');
				$("body div#answer div#itens").append('<p class="item" onClick="speek(`'+questionsN[c]+'`)">' + c + ') ' + questions[c] + '</p>');
				$("body div#answer div#itens").append('<p class="answer" onClick="speek(`'+answersN[c]+'`)">' + answers[c] + '</p>');
			}
		});
	});
	
	$("body div#question button#showAnswers").click(function(){
		window.scrollTo(0, 0);
		$("body div#question").css("display", "none");
		$("body div#answer").css("display", "block");
	});
});

function formatted(text){
	return text.replace(/[“]/g, '"').replace(/[”]/g, '"');
}
function speek(text){
	let nText = formatted(text);
	TTS.speak({
		text: nText,
		locale: "en-US",
		rate: speed
	}, function(){}, function(reason){
		dialog.alert("Houve algum erro: " + reason);
	});
}