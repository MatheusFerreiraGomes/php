var iframe = null;
$("document").ready(function(){
	localStorage.setItem("pageNow", "buyNow");
});