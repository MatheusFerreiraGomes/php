$("document").ready(function(){
	localStorage.setItem("pageNow", "update");
	setTimeout(function(){
		$("body div").css("marginTop", "calc((100vh - "+$("body div").css("height")+") / 2)");
	}, 100);

	$("body div button#update").click(function(){
		if(platform == "android"){
			window.location = "market://details?id=com.es.english_swift";
		}
	});
});