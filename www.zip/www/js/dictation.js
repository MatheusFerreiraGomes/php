var lesson, dictation, dictationWithout;
var first = true, counter = 0, loop = 0;
var button = 1;
var dictationMode;
var timeStop, counterStop;
var right = 0, wrong = 0;
$("document").ready(function(){
	localStorage.setItem("pageNow", "dictation");
	$("body div#menu table tr td#icon").click(function(){
		sessionStorage.removeItem("dictationSelected");
		goToPage("home");
	});
	
	let dictationSelected = sessionStorage.getItem("dictationSelected");
	
	$("body div#menu table tr td.text").html("Ditado " + dictationSelected + "<span style='color: rgba(0, 0, 0, 0);'>afdffffffffafdfas</span>");
	
	database.transaction(function(tx){
		tx.executeSql("SELECT * FROM `dictation` WHERE `rowid`=" + dictationSelected, null, function(tx, results){
			let item = results.rows.item(0);
			lesson = item.lesson;
			dictation = item.dictation;
			dictationWithout = dictation.replace(/[?]/g,' question mark').replace(/[,]/g,' comma').replace(/[;]/g,' semi-colon').replace(/[.]/g,' full stop').replace(/[:]/g,' colon');
		});
	});
	
	$("body div#dictation table tr td#action button").click(function(){
		if(button == 1) selectMode();
		else{
			dialog.startLoader("Corrigindo...");
			$("body div#dictation").css("display", "none");
			$("body div#results").css("display", "block");
			if(timeStop == 0) clearInterval(counterStop);
			correct();
		}
	});
});

function speak(){
	let dictationSeparated = dictationWithout.split("/");
	let quantityDictation = parseInt(localStorage.getItem("quantityDictation"));
	if(counter < dictationSeparated.length){
		if(loop <= quantityDictation){
			textOut(dictationSeparated[counter]);
			setTimeout(function(){
				speak();
			}, 4000);
			loop++;
			if(loop == 3){
				counter++;
				loop = 0;
			}
		}
	}
	if(counter == (dictationSeparated.length - 1) && loop == 2){
		if(dictationMode == 1){
			dialog.alert("Acabou! Você terá 5 minutos para passar todo o ditado para o app e corrigir.");
			button = 2;
			M.toast({html: "Tempo iniciado!", classes: "green", "displayLength": 2000});
			$("body div#dictation table tr td#action").css("visibility", "visible");
			$("body div#dictation table tr td#action button").text("Corrigir!");
			timeStop = 300;
			$("body div#dictation table tr td#form p#time").css("display", "block");
			counterStop = setInterval(function(){
				$("body div#dictation table tr td#form p#time span#time").text(timeStop);
				timeStop--;
				if(timeStop == -1){
					clearInterval(counterStop);
					M.toast({html: "Tempo finalizado!", classes: "green", "displayLength": 2000});
					$("body div#dictation table tr td#form label textarea#dictation").attr("readonly", "readonly");
				}
			}, 1000);
		}
		else if(dictationMode == 2){
			dialog.alert("Acabou! Você terá 2 minutos para revisar o ditado e corrigir.");
			button = 2;
			M.toast({html: "Tempo iniciado!", classes: "green", "displayLength": 2000});
			$("body div#dictation table tr td#action").css("visibility", "visible");
			$("body div#dictation table tr td#action button").text("Corrigir!");
			timeStop = 120;
			$("body div#dictation table tr td#form p#time").css("display", "block");
			counterStop = setInterval(function(){
				$("body div#dictation table tr td#form p#time span#time").text(timeStop);
				timeStop--;
				if(timeStop == -1){
					clearInterval(counterStop);
					M.toast({html: "Tempo finalizado!", classes: "green", "displayLength": 2000});
					$("body div#dictation table tr td#form label textarea#dictation").attr("readonly", "readonly");
				}
			}, 1000);
		}
	}
}

function textOut(text){
	let speed = null;
	if(lesson >= 1 && lesson <= 4) speed = 0.75;
	if(lesson >= 5 && lesson <= 8) speed = 0.85;
	if(lesson >= 9 && lesson <= 12) speed = 0.95;
	TTS.speak({
		text: text,
		locale: "en-US",
		rate: speed
	}, function(){}, function(reason){
		dialog.alert("Houve algum erro: " + reason);
	});
}
function selectMode(){
	window.plugins.actionsheet.show({
		androidTheme: window.plugins.actionsheet.ANDROID_THEMES.THEME_DEVICE_DEFAULT_LIGHT,
		title: "Qual você prefere?",
		buttonLabels: ["Escrever no papel e depois passar para correção no app", "Fazer diretamente no app"],
		androidEnableCancelButton : false,
		addCancelButtonWithLabel: "Cancelar"
	}, function(buttonIndex){
		if(buttonIndex == 1){
			dictationMode = 1;
			startDictation();
		}
		else if(buttonIndex == 2){
			dictationMode = 2;
			startDictation();
		}
		else{
			selectMode();
		}
	});
}
function startDictation(){
	dialog.startLoader("Iniciando ditado...");
	setTimeout(function(){
		dialog.stopLoader();
		$("body div#dictation table tr td#action").css("visibility", "hidden");
		$("body div#dictation table tr td#form label textarea#dictation").removeAttr("readonly");
		M.toast({html: "Ditado iniciado!", classes: "green", "displayLength": 2000});
		speak();
	}, 2000);
}

function correct(){
	let dictationUser = $("body div#dictation table tr td#form label textarea#dictation").val();
	let totalSentences = "";
	let sentences = dictation.split("/");
	for(let c = 0; c < sentences.length; c++){
		totalSentences = totalSentences + sentences[c];
		
		if(c == (sentences.length - 1)){
			$("body div#results p#dictation").text(totalSentences);
			console.log(totalSentences)
			
			let sentenceSeparated = totalSentences.split(" ");
			let dictationUserSeparated = dictationUser.split(" ");
			
			for(let t = 0; t < sentenceSeparated.length; t++){
				if(sentenceSeparated[t] == dictationUserSeparated[t]){
					$("body div#results p#dictationUser").append(" " + dictationUserSeparated[t]);
					right++;
				}
				else{
					$("body div#results p#dictationUser").append(" <span style='color: red;'>" + dictationUserSeparated[t] + "</span>");
					wrong++;
				}
				
				if(t == (sentenceSeparated.length - 1)){
					$("body div#results p span#right").text(right + " - " + ((right / sentenceSeparated.length) * 100).toFixed(2) + "%");
					$("body div#results p span#wrong").text(wrong + " - " + ((wrong / sentenceSeparated.length) * 100).toFixed(2) + "%");
					dialog.stopLoader();
				}
			}
		}
	}
	
}