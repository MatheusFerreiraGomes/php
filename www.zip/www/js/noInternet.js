$("document").ready(function(){
	localStorage.setItem("pageNow", "noInternet");
	setTimeout(function(){
		$("body div").css("marginTop", "calc((100vh - "+$("body div").css("height")+") / 2)");
	}, 100);

	$("body div button#connection").click(function(){
		if(platform == "android"){
			window.cordova.plugins.settings.open("wireless", function(){},
				function () {
					dialog.alert("Houve algum problema ao abrir as configurações de internet, tente novamente.");
				}
			);
		}
		else{
			window.cordova.plugins.settings.open("network", function(){},
				function () {
					dialog.alert("Houve algum problema ao abrir as configurações de internet, tente novamente.");
				}
			);
		}
	});
});