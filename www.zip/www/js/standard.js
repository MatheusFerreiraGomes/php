var platform = null;
var permissions;
var notificationOptions = null;
var notificationInternet = 1;
var permissions;
var setterStatus;
var inAppBrowserRef;
const oneSignalId = "7a9e7048-5596-4f68-ad63-843298b894c2";
const CREDENTIALS = {
	appId: 4162,
	authKey: "aUMbU3ra9YrrDgd",
	authSecret: "6YDkMCj5WMJL3PN"
};
window.onload = function(){
	localStorage.setItem("network", 0);
	localStorage.setItem("message", 0);
};
function onDeviceReady(){
	window.plugins.insomnia.keepAwake();	
	permissions = cordova.plugins.permissions;
	cordova.plugins.backgroundMode.disableWebViewOptimizations();
	
	var objCanvas = document.getElementById('canvas');
    //window.plugin.CanvasCamera.initialize(objCanvas);
	
	let networkState = navigator.connection.type;
	let states = {};
	states[Connection.UNKNOWN]  = true;
	states[Connection.ETHERNET] = true;
	states[Connection.WIFI]     = true;
	states[Connection.CELL_2G]  = true;
	states[Connection.CELL_3G]  = true;
	states[Connection.CELL_4G]  = true;
	states[Connection.CELL]     = true;
	states[Connection.NONE]     = false;				
	localStorage.setItem("typeConnection", states[networkState]);
	
	platform = device.platform.toLowerCase();
	if(localStorage.getItem("platform") == undefined) localStorage.setItem("platform", platform);

	let notificationOpenedCallback = function(data){
		let title = data.notification.payload.title;
		let body = data.notification.payload.body;
		let bigPicture = data.notification.payload.largeIcon;
		let color = data.notification.payload.smallIconAccentColor;
		cordova.plugins.notification.local.schedule({
			title: title,
			text: body,
			smallIcon: 'res://ic_notification',
			icon: bigPicture,
			color: color
		});
	};
	window.plugins.OneSignal.startInit(oneSignalId).handleNotificationOpened(notificationOpenedCallback).endInit();
	
	let page = localStorage.getItem("pageNow");
	
	if(page != "index" || page != "useTerms" || page != "privacy") StatusBar.styleLightContent();
	if(page != "update" && page != "maintance"){
		cordova.getAppVersion.getVersionNumber().then(function(tVersion){
			$.getJSON(urlSystem + "appSystem.php?id=1", function(results){
				let maintance = results["maintance"];
				let version = results["version"];
				
				if(maintance == 1) goToPage("maintance");
				else if(tVersion != version) goToPage("update");
			});
		});
	}
	
	if(page == "index"){
		StatusBar.backgroundColorByHexString("#ffffff");
		StatusBar.styleDefault();
	}
	if(page == "options"){
		StatusBar.backgroundColorByHexString("#ffffff");
		StatusBar.styleDefault();
	}
	if(page == "login"){
		StatusBar.backgroundColorByHexString("#f2f2f2");
		StatusBar.styleDefault();
	}
	if(page == "register"){
		StatusBar.backgroundColorByHexString("#f2f2f2");
		StatusBar.styleDefault();
	}
	if(page == "useTerms" || page == "privacy"){
		StatusBar.backgroundColorByHexString("#f2f2f2");
		StatusBar.styleDefault();
	}
	if(page == "recoveryPassword"){
		StatusBar.backgroundColorByHexString("#f2f2f2");
		StatusBar.styleDefault();
	}
	if(page == "home"){
		StatusBar.backgroundColorByHexString("#1048c5");
		
		if(sessionStorage.getItem("backgroundMode") == undefined){
			sessionStorage.setItem("backgroundMode", 1);
			cordova.plugins.backgroundMode.setDefaults({silent: true});
			cordova.plugins.backgroundMode.enable();
		}
		
		cordova.getAppVersion.getVersionNumber().then(function(version){
			$("body div#settings p#version").text("Versão: " + version);
		});
		window.plugins.OneSignal.getIds(function(ids) {
			let userID = ids.userId;
			database.transaction(function(transaction){
				transaction.executeSql("SELECT * FROM `user` WHERE `rowid`=1", null, function(tx, results){
					let item = results.rows.item(0);
					$.ajax({
						method: "POST", 
						url: urlSystem + "saveOneSignalID.php",
						data: {
							email: item.email,
							onesignal: userID
						}
					});
				});
			});
		});
		
		if(localStorage.getItem("uses") == undefined)  localStorage.setItem("uses", 1);
		else{
			if(sessionStorage.getItem("settingsUses") == undefined){
				sessionStorage.setItem("settingsUses", 1);
				localStorage.setItem("uses", parseInt(localStorage.getItem("uses")) + 1);
				if( parseInt(localStorage.getItem("uses")) == 3){
					navigator.notification.confirm(
						"Está gostando do English Swift?",
						function(buttonIndex){
							if(buttonIndex == 1){
								navigator.notification.confirm(
									"Poderia nos avaliar agora? Isso ajudará no crescimento do app e a outras pessoas também a aprenderem Inglês.",
									function(buttonIndex){
										if(buttonIndex == 1){
											localStorage.setItem("uses", 4);
											LaunchReview.launch(function(){},function(err){
												localStorage.setItem("uses", 3);
												dialog.alert("Houve algum erro ao abrir Play Store para avaliação, tente novamente.");
											}, packageApp);
										}
										else{
											localStorage.setItem("uses", 2);
										}
									}, 
									"",
									["Sim", "Mais tarde"]
								);
							}
							else{
								localStorage.setItem("uses", 4);
								navigator.notification.confirm(
									"Poderia nos dizer porque não está gostando?",
									function(buttonIndex){
										if(buttonIndex == 1){
											window.open("mailto:englishswiftapp@gmail.com", "_system");
										}
									}, 
									"",
									["Sim", "Não"]
								);
							}
						}, 
						"NOS AVALIE!",
						["Sim", "Não"]
					);
				}
			}
		}
		
		onlineStatus();
	}
	if(page == "contact"){
		StatusBar.backgroundColorByHexString("#f2f2f2");
		StatusBar.styleDefault();
	}
	if(page == "accountType"){
		StatusBar.backgroundColorByHexString("#f2f2f2");
		StatusBar.styleDefault();
		database.transaction(function(transaction){
			transaction.executeSql("SELECT * FROM `user` WHERE `rowid`=1", null, function(transaction, results){
				dialog.startLoader("Carregando...");
				let email = results.rows.item(0).email;
				$.getJSON(urlSystem + "getAccountType.php?email=" + email, function(results){
					let type = results["type"];
					let date = results["date"];
					let time = results["time"];
					
					if(type == 0){
						$("body div#accountType p#accountType span").text("Versão de avaliação");
						$("body div#accountType p#access span").text(date + " - " + time);
					}
					else{
						$("body div#accountType p#accountType span").text("Acesso completo");
						$("body div#accountType p#access span").text("Vitalício");
						$("body div#accountType button#buy").css("display", "none");
					}
					
					dialog.stopLoader();
				});
			});
		});
	}
	if(page == "noInternet"){
		StatusBar.backgroundColorByHexString("#f2f2f2");
		StatusBar.styleDefault();
	}
	if(page == "update"){
		StatusBar.backgroundColorByHexString("#f2f2f2");
		StatusBar.styleDefault();
	}
	if(page == "maintance"){
		StatusBar.backgroundColorByHexString("#f2f2f2");
		StatusBar.styleDefault();
	}
	if(page == "myAccount"){
		StatusBar.backgroundColorByHexString("#f2f2f2");
		StatusBar.styleDefault();
		dialog.startLoader("Carregando...");
		database.transaction(function(transaction){
			transaction.executeSql("SELECT * FROM `user` WHERE `rowid`=1", null, function(transaction, results){
				let item = results.rows.item(0);
				let picture = item.picture;
				let p = null;
				let date = new Date();
				
				if(picture == "profile.png") p = "img/profile.png";
				else p = url + "profiles/" + picture + "?=" + date.getTime();
				
				$("body div#myAccount img#picture").attr("src", p);
				$("body div#myAccount p#name").text(item.fullName);
				$("body div#myAccount p#email").text(item.email);
				$("body div#myAccount p#birthDate").text(item.birthDate);
				$("body div#myAccount p#phoneNumber").text(item.phoneNumber);
				dialog.stopLoader();
			});
		});
	}
	if(page == "changePassword"){
		StatusBar.backgroundColorByHexString("#f2f2f2");
		StatusBar.styleDefault();
	}
	if(page == "changePhoneNumber"){
		StatusBar.backgroundColorByHexString("#f2f2f2");
		StatusBar.styleDefault();
	}
	if(page == "translater"){
		StatusBar.backgroundColorByHexString("#f2f2f2");
		StatusBar.styleDefault();
		keyboardSettings();
	}
	if(page == "dictation"){
		StatusBar.backgroundColorByHexString("#f2f2f2");
		StatusBar.styleDefault();
		keyboardSettings();
		dialog.startLoader("Iniciando...");
		setTimeout(function(){
			dialog.stopLoader();
		}, 2000);
	}
	if(page == "story"){
		StatusBar.backgroundColorByHexString("#f2f2f2");
		StatusBar.styleDefault();
		dialog.startLoader("Carregando...");
		setTimeout(function(){
			dialog.stopLoader();
			window.HeadsetDetection.detect(function(detected){
				if(detected == false){
					dialog.alert("Para uma melhor experiência e aprendizado, recomendamos que escute a história usando um fone de ouvido.");
				}
			});
		}, 2000);
	}
	if(page == "revision"){
		StatusBar.backgroundColorByHexString("#f2f2f2");
		StatusBar.styleDefault();
		dialog.startLoader("Carregando...");
		setTimeout(function(){
			dialog.stopLoader();
		}, 2000);
	}
	if(page == "lesson"){
		StatusBar.backgroundColorByHexString("#f2f2f2");
		StatusBar.styleDefault();
	}
	if(page == "buyNow"){
		dialog.startLoader("Carregando...");
		StatusBar.backgroundColorByHexString("#f2f2f2");
		StatusBar.styleDefault();
		database.transaction(function(transaction){
			transaction.executeSql("SELECT * FROM `user` WHERE `rowid`=1", null, function(transaction, results){
				let email = results.rows.item(0).email;
				inAppBrowserRef = cordova.InAppBrowser.open(urlSystem + "payment/payment.php?email=" + email, "_blank", "hidden=yes,zoom=no,hideurlbar=no,hardwareback=no,location=no,clearcache=no,clearsessioncache=no,fullscreen=yes");
				
				inAppBrowserRef.addEventListener("loadstop", function(){
					inAppBrowserRef.show();
					dialog.stopLoader();
					setInterval(function(){						
						inAppBrowserRef.executeScript({code: "\
							var messageObj = {id_message: idMessage};\
							var stringifiedMessageObj = JSON.stringify(messageObj);\
							webkit.messageHandlers.cordova_iab.postMessage(stringifiedMessageObj);"
						});
					}, 500);
				});
				
				inAppBrowserRef.addEventListener("message", function(event){
					let idMessage = event["data"]["id_message"];
					if(idMessage == 1) goToPage("home");
					if(idMessage == 2){
						window.plugins.toast.showWithOptions({
							message: "Preencha o CPF corretamente.", duration: "short", position: "bottom",
							styling: {opacity: 1, backgroundColor: "#FF0000", textColor: "#FFFFFF", textSize: 14, cornerRadius: 16, horizontalPadding: 20, verticalPadding: 16}
						});
						inAppBrowserRef.executeScript({code: "\
							idMessage = 0;"
						});
					}
					if(idMessage == 3){
						window.plugins.toast.showWithOptions({
							message: "CPF inválido.", duration: "short", position: "bottom",
							styling: {opacity: 1, backgroundColor: "#FF0000", textColor: "#FFFFFF", textSize: 14, cornerRadius: 16, horizontalPadding: 20, verticalPadding: 16}
						});
						inAppBrowserRef.executeScript({code: "\
							idMessage = 0;"
						});
					}
					if(idMessage == 4){
						dialog.alert("Pedimos essa informação para finalizar a transação pelo sistema do Pagseguro e provar que você não é um rôbo.");
						inAppBrowserRef.executeScript({code: "\
							idMessage = 0;"
						});
					}
					if(idMessage == 5){
						dialog.startLoader("Buscando CEP...");
						inAppBrowserRef.executeScript({code: "\
							idMessage = 0;"
						});
					}
					if(idMessage == 6){
						dialog.stopLoader();
						inAppBrowserRef.executeScript({code: "\
							idMessage = 0;"
						});
					}
					if(idMessage == 7){
						dialog.stopLoader();
						dialog.alert("Endereço não encontrado.");
						inAppBrowserRef.executeScript({code: "\
							idMessage = 0;"
						});
					}
					if(idMessage == 8){
						window.plugins.toast.showWithOptions({
							message: "Preencha os campos corretamente.", duration: "short", position: "bottom",
							styling: {opacity: 1, backgroundColor: "#FF0000", textColor: "#FFFFFF", textSize: 14, cornerRadius: 16, horizontalPadding: 20, verticalPadding: 16}
						});
						inAppBrowserRef.executeScript({code: "\
							idMessage = 0;"
						});
					}
					if(idMessage == 9){
						window.plugins.toast.showWithOptions({
							message: "CEP inválido.", duration: "short", position: "bottom",
							styling: {opacity: 1, backgroundColor: "#FF0000", textColor: "#FFFFFF", textSize: 14, cornerRadius: 16, horizontalPadding: 20, verticalPadding: 16}
						});
						inAppBrowserRef.executeScript({code: "\
							idMessage = 0;"
						});
					}
				});
				
				inAppBrowserRef.addEventListener("exit", function(){
					goToPage("home");
				});
			});
		});
	}

	
	document.addEventListener("backbutton", backButton, false);
	document.addEventListener("offline", onOffline, false);
    document.addEventListener("online", onOnline, false);
	document.addEventListener("resume", onResume, false);
    document.addEventListener("pause", onPause, false);
}
function onOffline(){
	let networkState = navigator.connection.type;
	let states = {};
	states[Connection.UNKNOWN]  = true;
	states[Connection.ETHERNET] = true;
	states[Connection.WIFI]     = true;
	states[Connection.CELL_2G]  = true;
	states[Connection.CELL_3G]  = true;
	states[Connection.CELL_4G]  = true;
	states[Connection.CELL]     = true;
	states[Connection.NONE]     = false;				
	localStorage.setItem("typeConnection", states[networkState]);
	
	let page = localStorage.getItem("pageNow");	
	let list = ["options", "login", "register", "recoveryPassword", "home", "dictation", "story", "revision"];
	
	if(list.indexOf(page) > -1){
		sessionStorage.setItem("backOnline", page);
		goToPage("noInternet");
	}
}
function onOnline(){
	let networkState = navigator.connection.type;
	let states = {};
	states[Connection.UNKNOWN]  = true;
	states[Connection.ETHERNET] = true;
	states[Connection.WIFI]     = true;
	states[Connection.CELL_2G]  = true;
	states[Connection.CELL_3G]  = true;
	states[Connection.CELL_4G]  = true;
	states[Connection.CELL]     = true;
	states[Connection.NONE]     = false;				
	localStorage.setItem("typeConnection", states[networkState]);
	
	let page = localStorage.getItem("pageNow");
	
	if(page == "noInternet"){
		if(notificationInternet == 0){
			cordova.plugins.notification.local.schedule({
				title: "Opa, voltei! ☺️",
				text: "Sua conexão com internet foi restaurada com sucesso.",
				smallIcon: 'res://ic_notification',
				color: "1048c5"
			});
		}
		goToPage(sessionStorage.getItem("backOnline"));
	}
}
function onPause(){
	let page = localStorage.getItem("pageNow");
	if(page == "options"){
		cordova.plugins.backgroundMode.moveToBackground();
		notificationOptions = setTimeout(function(){
			cordova.plugins.notification.local.schedule({
				title: "Opa, esqueceu de mim? 😔",
				text: "Comece hoje a estudar e aprender Inglês da melhor maneira e interagindo com outros como você.",
				smallIcon: 'res://ic_notification',
				color: "1048c5"
			});
		}, 300000);
	}
	if(page == "home"){
		clearInterval(setterStatus);
		database.transaction(function(transaction){
			transaction.executeSql("SELECT * FROM `user` WHERE `rowid`=1", null, function(tx, results){
				let item = results.rows.item(0);
				$.ajax({
					method: "POST",
					url: urlSystem + "setStatusChat.php",
					data: {
						email: item.email,
						status:  "offline"
					}
				});
			});
		});
	}
	if(page == "noInternet"){
		notificationInternet = 0;
	}
}
function onResume(){
	let page = localStorage.getItem("pageNow");
	if(page == "options"){
		clearTimeout(notificationOptions);
	}
	if(page == "home"){
		onlineStatus();
	}
	if(page == "noInternet"){
		notificationInternet = 1;
	}
}
function backButton(){
	let page = localStorage.getItem("pageNow");
	if(page == "index"){
		navigator.app.exitApp();
	}
	if(page == "options"){
		cordova.plugins.backgroundMode.moveToBackground();
		notificationOptions = setTimeout(function(){
			cordova.plugins.notification.local.schedule({
				title: "Opa, esqueceu de mim? 😔",
				text: "Comece hoje a estudar e aprender Inglês da melhor maneira e interagindo com outros como você.",
				smallIcon: 'res://ic_notification',
				color: "1048c5"
			});
		}, 300000);
	}
	if(page == "login"){
		goToPage("options");
	}
	if(page == "register"){
		goToPage("options");
	}
	if(page == "useTerms" || page == "privacy"){
		goToPage(sessionStorage.getItem("pageBack"));
	}
	if(page == "recoveryPassword"){
		goToPage("login");
	}
	if(page == "home"){
		if($("body div#conversation").css("display") == "block"){
			if($("body div#conversation div#chat div#emojis").css("display") == "block"){
				$("body div#conversation div#chat div#emojis").css("display", "none");
				$("body div#conversation div#chat div#messages").css("height", "calc(100vh - (4rem + 4.5rem))");
			}
			else goOutChat();
		}
		else{
			navigator.notification.confirm(
				"Tem certeza que deseja finalizar o aplicativo?",
				function(buttonIndex){
					if(buttonIndex == 1) cordova.plugins.backgroundMode.moveToBackground();
				}, 
				"",
				["Sim", "Não"]
			);
		}
	}
	if(page == "noInternet"){
		cordova.plugins.backgroundMode.moveToBackground();
	}
	if(page == "update"){
		navigator.app.exitApp();
	}
	if(page == "maintance"){
		navigator.app.exitApp();
	}
	if(page == "translater"){
		goToPage("home");
	}
	if(page == "dictation"){
		sessionStorage.removeItem("dictationSelected");
		goToPage("home");
	}
	if(page == "story"){
		sessionStorage.removeItem("storySelected");
		goToPage("home");
	}
	if(page == "revision"){
		sessionStorage.removeItem("revisionSelected");
		goToPage("home");
	}
	if(page == "lesson"){
		sessionStorage.removeItem("lessonSeleted");
		localStorage.setItem("pageNow", "home");
		window.open("../home.html", "_self");
	}
	if(page == "contact"){
		goToPage("home");
	}
	if(page == "accountType"){
		goToPage("home");
	}
	if(page == "myAccount"){
		goToPage("home");
	}
	if(page == "changePassword"){
		goToPage("myAccount");
	}
	if(page == "changePhoneNumber"){
		goToPage("myAccount");
	}
	if(page == "buyNow"){
		inAppBrowserRef.close();
		goToPage("home");
	}
}
document.addEventListener("deviceready", onDeviceReady, false);
function AbreUrl(url){
	navigator.app.loadUrl(url,{openExternal: true});
}
function goToPage(page){
	localStorage.setItem("pageNow", page);
	window.open(page + ".html", "_self");
}
function keyboardSettings(){
	if(localStorage.getItem("settingsKeyboard") == 0){
		window.plugins.actionsheet.show({
			androidTheme: window.plugins.actionsheet.ANDROID_THEMES.THEME_DEVICE_DEFAULT_LIGHT,
			title: "Deseja adicionar mais teclado para melhor estudos?",
			buttonLabels: ["Sim", "Não", "Não e não mostrar essa mensagem novamente"],
			androidEnableCancelButton : false,
			addCancelButtonWithLabel: "Cancelar"
		}, function(buttonIndex){
			if(buttonIndex == 1){
				if(platform == "android"){
					window.cordova.plugins.settings.open("keyboard_subtype", function(){
							localStorage.setItem("settingsKeyboard", 1);
						},
						function(){
							dialog.alert("Houve algum problema ao abrir as configurações de teclado.");
						}
					);
				}
				else{
					window.cordova.plugins.settings.open("keyboards", function(){
							localStorage.setItem("settingsKeyboard", 1);
						},
						function(){
							dialog.alert("Houve algum problema ao abrir as configurações de teclado.");
						}
					);
				}
			}
			if(buttonIndex == 3){
				localStorage.setItem("settingsKeyboard", 1);
			}
		});
	}
}
function onlineStatus(){
	database.transaction(function(transaction){
		transaction.executeSql("SELECT * FROM `user` WHERE `rowid`=1", null, function(tx, results){
			let item = results.rows.item(0);
			$.ajax({
				method: "POST",
				url: urlSystem + "setStatusChat.php",
				data: {
					email: item.email,
					status:  "online"
				}
			}).done(function(){
				setterStatus = setInterval(function(){
					database.transaction(function(transaction){
						transaction.executeSql("SELECT * FROM `user` WHERE `rowid`=1", null, function(tx, results){
							let item = results.rows.item(0);
							$.ajax({
								method: "POST",
								url: urlSystem + "setStatusChat.php",
								data: {
									email: item.email,
									status:  "online"
								}
							});
						});
					});
				}, 60000);
			});
		});
	});
}
