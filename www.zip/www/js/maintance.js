$("document").ready(function(){
	localStorage.setItem("pageNow", "maintance");
	setTimeout(function(){
		$("body div").css("marginTop", "calc((100vh - "+$("body div").css("height")+") / 2)");
	}, 100);
});