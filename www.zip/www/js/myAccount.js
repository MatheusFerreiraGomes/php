$("document").ready(function(){
	localStorage.setItem("pageNow", "myAccount");
	$("body div#menu table tr td#icon").click(function(){
		goToPage("home");
	});
	
	$("body div#myAccount button#changePicture").click(function(){
		database.transaction(function(transaction){
			transaction.executeSql("SELECT * FROM `user` WHERE `rowid`=1", null, function(transaction, results){
				let email = results.rows.item(0).email;
				$.getJSON(urlSystem + "getAccountType.php?email=" + email, function(results){
					let type = results["type"];
					if(type == 0){
						navigator.notification.confirm(
							"Recurso somente para pagantes.\nDeseja se tornar um agora?",
							function(buttonIndex){
								if(buttonIndex == 1) goToPage("buyNow");
							}, 
							"",
							["Sim", "Não"]
						);
					}
					else{
						database.transaction(function(transaction){
							transaction.executeSql("SELECT * FROM `user` WHERE `rowid`=1", null, function(transaction, results){
								let picture = results.rows.item(0).picture;
								
								if(picture == "profile.png"){
									$("body div#myAccount form#changeProfile #file").click();
								}
								else{
									window.plugins.actionsheet.show({
										androidTheme: window.plugins.actionsheet.ANDROID_THEMES.THEME_DEVICE_DEFAULT_LIGHT,
										title: "O que deseja fazer?",
										buttonLabels: ["Alterar foto de perfil", "Remover foto de perfil"],
										androidEnableCancelButton : false,
										addCancelButtonWithLabel: "Cancelar"
									}, function(buttonIndex){
										if(buttonIndex == 1){
											$("body div#myAccount form#changeProfile #file").click();
										}
										else{
											dialog.startLoader("Carregando...");
											database.transaction(function(transaction){
												transaction.executeSql("SELECT * FROM `user` WHERE `rowid`=1", null, function(transaction, results){
													let email = results.rows.item(0).email;
													$.ajax({
														url: urlSystem + "removeProfile.php?email=" + email
													}).done(function(r){
														dialog.stopLoader();
														if(r == 0){
															dialog.alert("Houve algum erro, tente novamente.");
														}
														else{
															database.transaction(function(transaction){
																transaction.executeSql("UPDATE `user` SET `picture`='"+r+"' WHERE `rowid`=1 ", null, function(){
																	goToPage("myAccount");
																});
															});
														}
													}).fail(function(){
														dialog.stopLoader();
														dialog.alert("Houve algum erro, tente novamente.");
													});
												});
											});
										}
									});
								}
							});
						});
					}
				});
			});
		});
	});
	
	$("body div#myAccount button#changePhoneNumber").click(function(){
		goToPage("changePhoneNumber");
	});
	$("body div#myAccount button#changePassword").click(function(){
		goToPage("changePassword");
	});
});

function changeProfile(){
	dialog.startLoader("Carregando...");
	database.transaction(function(transaction){
		transaction.executeSql("SELECT * FROM `user` WHERE `rowid`=1", null, function(transaction, results){
			let email = results.rows.item(0).email;
			var fd = new FormData();
			var files = $("body div#myAccount form#changeProfile #file")[0].files[0];
			fd.append("file",files);
			
			let mode;
			
			if(results.rows.item(0).picture == "profile.png") mode = "new";
			else mode = "change";
			
			$.ajax({
				url: urlSystem + "setProfile.php?email=" + email + "&mode=" + mode,
				type: 'post',
				data: fd,
				contentType: false,
				processData: false,
			}).done(function(r){
				dialog.stopLoader();
				if(r == 0){
					dialog.alert("Foto de perfil com extensão inválida.");
				}
				else if(r == 1){
					dialog.alert("Houve algum erro, tente novamente.");
				}
				else{
					database.transaction(function(transaction){
						transaction.executeSql("UPDATE `user` SET `picture`='"+r+"' WHERE `rowid`=1 ", null, function(){
							goToPage("myAccount");
						});
					});
				}
			});
		});
	});
}