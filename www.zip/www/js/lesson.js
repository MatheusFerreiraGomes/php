var touchtime = 0, delay = 800, action = null;
var lesson, speed;
$("document").ready(function(){
	localStorage.setItem("pageNow", "lesson");
	
	let lessonSelected = parseInt(sessionStorage.getItem("lessonSeleted"));
	
	$("body div#menu table tr td#icon").click(function(){
		sessionStorage.removeItem("lessonSeleted");
		localStorage.setItem("pageNow", "home");
		window.open("../home.html", "_self");
	});
	
	if(lessonSelected >= 1 && lessonSelected <= 9) lesson = 1;
	else if(lessonSelected >= 10 && lessonSelected <= 24) lesson = 2;
	else if(lessonSelected >= 25 && lessonSelected <= 40) lesson = 3;
	else if(lessonSelected >= 41 && lessonSelected <= 60) lesson = 4;
	else if(lessonSelected >= 61 && lessonSelected <= 77) lesson = 5;
	else if(lessonSelected >= 78 && lessonSelected <= 94) lesson = 6;
	else if(lessonSelected >= 95 && lessonSelected <= 111) lesson = 7;
	else if(lessonSelected >= 112 && lessonSelected <= 126) lesson = 8;
	else if(lessonSelected >= 127 && lessonSelected <= 145) lesson = 9;
	else if(lessonSelected >= 146 && lessonSelected <= 163) lesson = 10;
	else if(lessonSelected >= 164 && lessonSelected <= 177) lesson = 11;
	else if(lessonSelected >= 178 && lessonSelected <= 191) lesson = 12;
	
	if(lesson >= 1 && lesson <= 4) speed = 0.75;
	else if(lesson >= 5 && lesson <= 8) speed = 0.85;
	else if(lesson >= 9 && lesson <= 12) speed = 0.95;
	
	let urlCharts = url + "charts/chart-";
	$("body div#lesson img#chart1").attr("src", urlCharts + 1 + ".png");	
	$("body div#lesson img#chart2").attr("src", urlCharts + 2 + ".png");	
	$("body div#lesson img#chart3").attr("src", urlCharts + 3 + ".png");	
	$("body div#lesson img#chart4").attr("src", urlCharts + 4 + ".png");	
	$("body div#lesson img#chart5").attr("src", urlCharts + 5 + ".png");	
	
	$("body div#lesson button#finished").click(function(){
		alert("finalizar lição!");
	});
	
});

function speak(textInEnglish, textInPortuguese){
	/*Double Click */
  if((new Date().getTime() - touchtime) < delay){
     clearTimeout(action)
     speakInPortuguese(textInPortuguese);
     touchtime = 0;
  }
  /* Single Click */
  else{
     touchtime = new Date().getTime();
     action = setTimeout(function(){
        speakInEnglish(textInEnglish);
     },delay);
  }
}

function speakInEnglish(text){
	TTS.speak({
		text: text,
		locale: "en-US",
		rate: 0.9
	}, function(){}, function(reason){
		dialog.alert("Houve algum erro: " + reason);
	});
}
function speakInPortuguese(text){
	TTS.speak({
		text: text,
		locale: "pt-BR",
		rate: 0.9
	}, function(){}, function(reason){
		dialog.alert("Houve algum erro: " + reason);
	});
}

function speakInEnglishExercise(text){
	TTS.speak({
		text: text,
		locale: "en-US",
		rate: speed
	}, function(){}, function(reason){
		dialog.alert("Houve algum erro: " + reason);
	});
}
