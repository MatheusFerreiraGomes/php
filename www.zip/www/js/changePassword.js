$("document").ready(function(){
	localStorage.setItem("pageNow", "changePassword");
	$("body div#menu table tr td#icon").click(function(){
		goToPage("myAccount");
	});
	
	$("body div#changePassword form#changePassword label .field").focus(function(){
		$(this).css("border", "1px solid #f5f6fa");
	});
	
	$("body div#changePassword form#changePassword").submit(function(e){
		e.preventDefault();
		let lastPassword = $("body div#changePassword form#changePassword label #lastPassword").val();
		let password = $("body div#changePassword form#changePassword label #password").val();
		let passwordConfirm = $("body div#changePassword form#changePassword label #passwordConfirm").val();
		
		if(lastPassword.length == 0 || password.length == 0 || passwordConfirm.length == 0){
			M.toast({html: "Preencha os campos corretamente.", classes: "red", displayLength: 2000});
			if(lastPassword.length == 0) $("body div#changePassword form#changePassword label #lastPassword").css("border", "1px solid red");
			if(password.length == 0) $("body div#changePassword form#changePassword label #password").css("border", "1px solid red");
			if(passwordConfirm.length == 0) $("body div#changePassword form#changePassword label #passwordConfirm").css("border", "1px solid red");
		}
		else if(lastPassword.length <= 7 || password.length <= 7 || passwordConfirm.length <= 7){
			M.toast({html: "Senhas devem ter no mínimo 8 dígitos.", classes: "red", displayLength: 2000});
			if(lastPassword.length <= 7) $("body div#changePassword form#changePassword label #lastPassword").css("border", "1px solid red");
			if(password.length <= 7) $("body div#changePassword form#changePassword label #password").css("border", "1px solid red");
			if(passwordConfirm.length <= 7) $("body div#changePassword form#changePassword label #passwordConfirm").css("border", "1px solid red");
		}
		else if(password != passwordConfirm){
			M.toast({html: "Senhas não coincidem.", classes: "red", displayLength: 2000});
			$("body div#changePassword form#changePassword label #password").css("border", "1px solid red");
			$("body div#changePassword form#changePassword label #passwordConfirm").css("border", "1px solid red");
		}
		else{
			dialog.startLoader("Alterando senha...");
			database.transaction(function(transaction){
				transaction.executeSql("SELECT * FROM `user` WHERE `rowid`=1", null, function(transaction, results){
					let email = results.rows.item(0).email;
					$.ajax({
						method: "POST",
						url: urlSystem + "changePassword.php",
						data: {
							email: email,
							lastPassword: md5(lastPassword),
							newPassword: md5(password)
						}
					}).done(function(results){
						dialog.stopLoader();
						if(results == 0){
							M.toast({html: "Senha atual incorreta!", classes: "red", displayLength: 2000});
						}
						else if(results == 1){
							$("body div#changePassword form#changePassword label #lastPassword").val("");
							$("body div#changePassword form#changePassword label #password").val("");
							$("body div#changePassword form#changePassword label #passwordConfirm").val("");
							M.toast({html: "Senha alterada com sucesso!", classes: "green", displayLength: 2000});
						}
					});
				});
			});
		}
	});
	
	
});