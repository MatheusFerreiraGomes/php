var setDDD = 0;
$("document").ready(function(){
	localStorage.setItem("pageNow", "changePhoneNumber");
	$("body div#menu table tr td#icon").click(function(){
		goToPage("myAccount");
	});
	
	$("body div#changePhoneNumber form#changePhoneNumber label .field").focus(function(){
		$(this).css("border", "1px solid #f5f6fa");
	});
	
	$("body div#changePhoneNumber form#changePhoneNumber label #phoneNumber").focus(function(){
		if($(this).val().length == 0) $(this).val("(");
	});
	$("body div#changePhoneNumber form#changePhoneNumber label #phoneNumber").blur(function(){
		let val = $(this).val();
		if(val == "(") $(this).val("");
	});
	$("body div#changePhoneNumber form#changePhoneNumber label #phoneNumber").keydown(function(){
		let val = $(this).val();
		if(val.substring(0, 1) == "(" && val.length == 2 && val.substring(2, 3) != ") "){
			setDDD = 1;
		}
	});
	$("body div#changePhoneNumber form#changePhoneNumber label #phoneNumber").keyup(function(){
		let val = $(this).val();
		if(setDDD == 1 && val != "("){
			$(this).val(val + ") ");
			setDDD = 0;
		}
		else setDDD = 0;
		if(val.length == 0) $(this).val("(");
	});
	
	$("body div#changePhoneNumber form#changePhoneNumber").submit(function(e){
		e.preventDefault();
		let phoneNumber = $("body div#changePhoneNumber form#changePhoneNumber label #phoneNumber").val();
		let password = $("body div#changePhoneNumber form#changePhoneNumber label #password").val();
		
		if(phoneNumber.length == 0 || password.length == 0){
			M.toast({html: "Preencha o campo corretamente.", classes: "red", displayLength: 2000});
			if(phoneNumber.length == 0) $("body div#changePhoneNumber form#changePhoneNumber label #phoneNumber").css("border", "1px solid red");
			if(password.length == 0) $("body div#changePhoneNumber form#changePhoneNumber label #password").css("border", "1px solid red");
		}
		else if(verifyPhone(phoneNumber) == false){
			M.toast({html: "Número de celular inválido.", classes: "red", displayLength: 2000});
			$("body div#changePhoneNumber form#changePhoneNumber label #phoneNumber").css("border", "1px solid red");
		}
		else if(password.length <= 7){
			M.toast({html: "Senha deve ter no mínimo 8 dígitos.", classes: "red", displayLength: 2000});
			$("body div#changePhoneNumber form#changePhoneNumber label #password").css("border", "1px solid red");
		}
		else{
			dialog.startLoader("Alterando número de celular...");
			database.transaction(function(transaction){
				transaction.executeSql("SELECT * FROM `user` WHERE `rowid`=1", null, function(transaction, results){
					let email = results.rows.item(0).email;
					$.ajax({
						method: "POST", 
						url: urlSystem + "changePhoneNumber.php",
						data: {
							email: email,
							phoneNumber: phoneNumber,
							password: md5(password)
						}
					}).done(function(r){
						dialog.stopLoader();
						if(r == 0){
							$("body div#changePhoneNumber form#changePhoneNumber label #password").css("border", "1px solid red");
							M.toast({html: "Senha incorreta.", classes: "red", displayLength: 2000});
						}
						else if(r == 1){
							$("body div#changePhoneNumber form#changePhoneNumber label #phoneNumber").css("border", "1px solid red");
							M.toast({html: "Esse número de celular já é seu cadastrado.", classes: "red", displayLength: 2000});
						}
						else if(r == 2){
							$("body div#changePhoneNumber form#changePhoneNumber label #phoneNumber").css("border", "1px solid red");
							M.toast({html: "Esse número de celular já está cadastrado.", classes: "red", displayLength: 2000});
						}
						else if(r == 3){
							database.transaction(function(transaction){
								transaction.executeSql("UPDATE `user` SET `phoneNumber`='"+phoneNumber+"' WHERE `rowid`=1", null, function(){
									$("body div#changePhoneNumber form#changePhoneNumber label #password").css("border", "1px solid #f5f6fa");
									$("body div#changePhoneNumber form#changePhoneNumber label #phoneNumber").css("border", "1px solid #f5f6fa");
									M.toast({html: "Número de celular alterado com sucesso!", classes: "green", displayLength: 2000});
									$("body div#changePhoneNumber form#changePhoneNumber label #phoneNumber").val("");
									$("body div#changePhoneNumber form#changePhoneNumber label #password").val("");
								});
							});
						}
					});
				});
			});
		}
	});
	
		
	
});

function verifyPhone(phone){
	if(/\([0-9]{2}\)[ ]?[0-9]{4,5}\-?[0-9]{4}$/.test(phone) == false) return false;
	else return true;
}