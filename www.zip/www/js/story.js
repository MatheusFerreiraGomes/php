$("document").ready(function(){
	localStorage.setItem("pageNow", "story");
	$("body div#menu table tr td#icon").click(function(){
		sessionStorage.removeItem("storySelected");
		goToPage("home");
	});
	
	let storySelected = sessionStorage.getItem("storySelected");
	
	$("body div#menu table tr td.text").html("História " + storySelected + "<span style='color: rgba(0, 0, 0, 0);'>afdffffffffafdfas</span>");
	
	database.transaction(function(tx){
		tx.executeSql("SELECT * FROM `stories` WHERE `id`=" + storySelected, null, function(tx, results){
			let item = results.rows.item(0);
			let nameEnglish = item.nameEnglish;
			let textEnglish = item.textEnglish;
			let namePortuguese = item.namePortuguese;
			let textPortuguese = item.textPortuguese;
			
			$("body div#story div#english p.title").text(nameEnglish);
			$("body div#story div#english p.text").text(textEnglish);
			$("body div#story div#portuguese p.title").text(namePortuguese);
			$("body div#story div#portuguese p.text").text(textPortuguese);
			$("body div#story audio").attr("src", url + "stories/story"+storySelected+".mp3");
		});
	});
	
	$("body div#story p#actionEnglish").click(function(){
		let cPortuguese = $("body div#story div#english").css("display");
		if(cPortuguese == "none"){
			$(this).text("Esconder a história em Inglês");
			$("body div#story div#english").css("display", "block");
		}
		else{
			$(this).text("Mostrar a história em Inglês");
			$("body div#story div#english").css("display", "none");
		}
	});
	
	$("body div#story p#actionPortuguese").click(function(){
		let cPortuguese = $("body div#story div#portuguese").css("display");
		if(cPortuguese == "none"){
			$(this).text("Esconder a história em Português");
			$("body div#story div#portuguese").css("display", "block");
		}
		else{
			$(this).text("Mostrar a história em Português");
			$("body div#story div#portuguese").css("display", "none");
		}
	});
	
});

