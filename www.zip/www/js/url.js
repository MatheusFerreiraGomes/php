//var url = "https://www.photoflowonline.com.br/English%20Swift/";
const url = "https://englishswiftapp.000webhostapp.com/";
const urlSystem = url + "app/";