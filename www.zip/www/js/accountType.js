$("document").ready(function(){
	localStorage.setItem("pageNow", "accountType");
	$("body div#menu table tr td#icon").click(function(){
		goToPage("home");
	});
	
	$("body div#accountType button#buy").click(function(){
		goToPage("buyNow");
	});
});