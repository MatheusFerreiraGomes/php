var warnStories = 0;
var peer; 
var packageApp = "com.es.english_swift";
var connected = 0, login, chat;
var connectedP2p = 0;
var myUserID = null;
var counterOnline, onlines = [], onlinesP2P = [], totalOnlines = [];
var inChat = 0, inChatP2P = 0, idUserChat = null, userChatStatus = 0, datesMessages = [], counterStatusFriend;
var warnNewMessages = 0;
var touchtime = 0, delay = 800, action = null;
var lastNotification = null;
var accountType = null, timeExpiration = null, dateExpiration;
var lastSenderId = null, counterMessagesLimit = 0, counterUserIdLimit = [];
var sDialog = 0;
$("document").ready(function(){
	localStorage.setItem("pageNow", "home");
	peer = new Peer(); 
	peer.on('open', function(id){
		connectedP2p = 1;
		database.transaction(function(transaction){
			transaction.executeSql("SELECT * FROM `user` WHERE `rowid`=1", null, function(tx, results){
				let item = results.rows.item(0);
				$.ajax({
					method: "POST", 
					url: urlSystem + "saveP2pID.php",
					data: {
						email: item.email,
						p2p: id
					}
				});
			});
		});
	});
	
	
	///////////////////////////
	//onlineStatus();
	//////////////////////////
	
	database.transaction(function(transaction){
		transaction.executeSql("SELECT * FROM `user` WHERE `rowid`=1", null, function(transaction, results){
			let email = results.rows.item(0).email;
			$.getJSON(urlSystem + "getAccountType.php?email=" + email, function(results){
				let type = results["type"];
				accountType = type;
				timeExpiration = results["time"];
				dateExpiration = results["date"];
				if(type == 1){
					$("body div#settings table tr#buyNow").remove();
					$("body div#settings table tr#spaceBuyNow").remove();
				}
				else{
					if(localStorage.getItem("noBuyerFirst") == undefined){
						localStorage.setItem("noBuyerFirst", 1);
						dialog.alert('Olá, vimos que você está usando a versão de avaliação, vamos te mostrar o que você tem direito a uso no app:\n\nEstudar todo o Estágio 1, em "Estudos" e "Prática";\n\nConversar com até 3 amigos no Chat;\n\nEscutar no máximo 5 histórias.\n\nEsperamos que você goste do English Swift e que possamos fazer a diferença pra você, bons estudos!', null, "BEM-VINDO!");
					}
					else{
						let date = new Date();
						let dateNow = ((date.getDate() <= 9) ? "0" + date.getDate() : date.getDate()) + "/" + (((date.getMonth() + 1) <= 9) ? "0" + (date.getMonth() + 1) : (date.getMonth() + 1)) + "/" +  date.getFullYear();
						if(dateNow == results["date"]){
							if(sessionStorage.getItem("warningLastDate") == undefined){
								sessionStorage.setItem("warningLastDate", 1);
								dialog.alert("Olá, vimos que hoje é seu último dia de avaliação, aproveite para estudar muito ou adquira o acesso completo.",  null, "EPA!");
							}
						}
					}
				}
			});
		});
	});
	
	peer.on('disconnected', function(){
		connectedP2p = 0;
		peer.reconnect();
		let id = peer["id"];
		connectedP2p = 1;
		database.transaction(function(transaction){
			transaction.executeSql("SELECT * FROM `user` WHERE `rowid`=1", null, function(tx, results){
				let item = results.rows.item(0);
				$.ajax({
					method: "POST", 
					url: urlSystem + "saveP2pID.php",
					data: {
						email: item.email,
						p2p: id
					}
				});
			});
		});
	});
	
	if(sessionStorage.getItem("pageBack") != undefined) sessionStorage.removeItem("pageBack");
	if(sessionStorage.getItem("dictationSelected") != undefined) sessionStorage.removeItem("dictationSelected");
	if(sessionStorage.getItem("storySelected") != undefined) sessionStorage.removeItem("storySelected");
	if(sessionStorage.getItem("revisionSelected") != undefined) sessionStorage.removeItem("revisionSelected");
	if(sessionStorage.getItem("lessonSeleted") != undefined) sessionStorage.removeItem("lessonSeleted");
	
	ConnectyCube.init(CREDENTIALS);
	
	database.transaction(function(transaction){
		transaction.executeSql("SELECT * FROM `user` WHERE `rowid`=1", null, function(tx, results){
			let item = results.rows.item(0);
			let date = new Date();
			$("body div#top table tr td#name").text(item.fullName.split(" ")[0] + " " + item.fullName.split(" ")[1]);
			if(item.picture == "profile.png") $("body div#top table tr td#profile img").attr("src", "img/profile.png");
			else $("body div#top table tr td#profile img").attr("src", url + "profiles/" + item.picture + "?=" + date.getTime());
			$.ajax({
				method: "POST",
				url: urlSystem + "getChatInfo.php",
				data:{
					email: item.email
				}
			}).done(function(r){
				let results = JSON.parse(r);
				myUserID = results["userID"];
				login = {login: item.email.split("@")[0], password: results["password"]};
				chat = {userId: results["userID"], password: results["password"]};
				connectServer();
			});
		});
	});
		
	
	$("body div#top table tr td#refresh").click(function(){
		dialog.startLoader("Atualizando...");
		setTimeout(function(){
			dialog.stopLoader();
			goToPage("home");
		}, 3000);
	});
	
	database.transaction(function(tx){
		tx.executeSql("SELECT * FROM `lessons`", null, function(tx, results){
			let length = results.rows.length;
			for(let c = 0; c < length; c++){
				let item = results.rows.item(c);
				for(let c = item.min; c <= item.max; c++){
					$("body div#studies table tr#book" + item.lesson + " td").append('<p onClick="selectLesson('+c+');"><i class="fa fa-angle-right"></i>&nbsp;&nbsp;Lição '+c+'</p>');
				}
			}
		});
	});
	
	$("body div#chat table#search tr td#search #search").focus(function(){
		$("body div#chat table#search tr td#search").css("border", "1px solid #f5f6fa");
	});
	$("body div#chat table#search tr td#searchButton").click(function(){
		let search = $("body div#chat table#search tr td#search #search").val();
		if(search.length == 0){
			M.toast({html: "Preencha para pesquisar.", classes: "red", displayLength: 2000});
			 $("body div#chat table#search tr td#search").css("borderTop", "1px solid red");
			 $("body div#chat table#search tr td#search").css("borderLeft", "1px solid red");
			 $("body div#chat table#search tr td#search").css("borderBottom", "1px solid red");
		}
		else{
			dialog.startLoader("Pesquisando pessoa...");
			database.transaction(function(transaction){
				transaction.executeSql("SELECT * FROM `user` WHERE `rowid`=1", null, function(transaction, results){
					let item = results.rows.item(0);
					$.getJSON(urlSystem + "searchUsers.php?search=" + search + "&myEmail=" + item.email, function(results){
						dialog.stopLoader();
						$("body div#chat div#resultsSearch table#list").html("");
						$("body div#chat div.content").css("display", "none");
						$("body div#chat table#menu").css("display", "none");
						$("body div#chat div#resultsSearch").css("display", "block");
						let length = results.length;
						if(length == 0){
							$("body div#chat div#resultsSearch p span#cancel").click();
							dialog.alert("Nenhum usuário encontrado.");
						}
						else{
							if(length == 1) $("body div#chat div#resultsSearch p span#results").text("1 usuário encontrado");
							else $("body div#chat div#resultsSearch p span#results").text(length + " usuários encontrados");
							
							for(let c = 0; c < length; c++){
							let date = new Date();
							let picture = null;
							if(results[c]["picture"] == "profile.png") picture = "img/profile.png";
							else picture = url + "profiles/" + results[c]["picture"] + "?=" + date.getTime();
							$("body div#chat div#resultsSearch table#list").append('<tr id="usr'+results[c]["userID"]+'"><td class="icon" onClick="startConversation('+results[c]["userID"]+');"><img src="'+picture+'" alt="Foto de Perfil"/></td><td class="name" onClick="startConversation('+results[c]["userID"]+');">'+results[c]["fullName"]+'</td><td class="settings" onClick="optionsChat('+results[c]["userID"]+');"><i class="fa fa-ellipsis-v"></i></td></tr>');
						}
					}
					});
				});
			});
		}
	});
	$("body div#chat div#resultsSearch p span#cancel").click(function(){
		$("body div#chat table#search tr td#search #search").val("");
		$("body div#chat div#resultsSearch").css("display", "none");
		$("body div#chat table#menu").css("display", "table");
		
		if($("body div#chat table#menu tr td button#online").css("color") == "rgb(16, 72, 197)") selectOptionChat("online");
		else if($("body div#chat table#menu tr td button#messages").css("color") == "rgb(16, 72, 197)") selectOptionChat("messages");
		else if($("body div#chat table#menu tr td button#calls").css("color") == "rgb(16, 72, 197)") selectOptionChat("calls");
	});
	
	database.transaction(function(tx){
		tx.executeSql("SELECT * FROM `stories`", null, function(tx, results){
			let length = results.rows.length;
			for(let c = 0; c < length; c++){
				let id = results.rows.item(c).id;
				let nameEnglish = results.rows.item(c).nameEnglish;
				$("body div#stories table").append('<tr Onclick="selectStory('+id+');"><td><i class="fa fa-angle-right"></i>&nbsp;&nbsp;'+nameEnglish+'</td></tr>');
			}
		});
	});
	
	database.transaction(function(tx){
		tx.executeSql("SELECT * FROM `dictations`", null, function(tx, results){
			let length = results.rows.length;
			for(let c = 0; c < length; c++){
				let item = results.rows.item(c);
				for(let c = item.min; c <= item.max; c++){
					$("body div#practise div#dictation table tr#book" + item.dictation + " td").append('<p onClick="selectDictation('+c+', '+item.dictation+');"><i class="fa fa-angle-right"></i>&nbsp;&nbsp;Ditado '+c+'</p>');
				}
			}
		});
	});
	
	database.transaction(function(tx){
		tx.executeSql("SELECT * FROM `questions`", null, function(tx, results){
			let length = results.rows.length;
			for(let c = 0; c < length; c++){
				let item = results.rows.item(c);
				$("body div#practise div#question table tr#book" + item.stage + " td").append('<p onClick="selectQuestion('+item.id+', '+item.stage+');" style="font-size: 1.3rem;"><i class="fa fa-angle-right"></i>&nbsp;&nbsp;Exercício de revisão '+item.id+' (Lições '+item.minLesson+' - '+item.maxLesson+')</p>');
			}
		});
	});
	
	$("body div#settings table tr#myAccount").click(function(){
		database.transaction(function(transaction){
			transaction.executeSql("SELECT * FROM `user` WHERE `rowid`=1", null, function(tx, results){
				let item = results.rows.item(0);
				$.ajax({
					method: "POST",
					url: urlSystem + "setStatusChat.php",
					data: {
						email: item.email,
						status:  "offline"
					}
				}).done(function(){
					goToPage("myAccount");
				});
			});
		});
	});
	
	
	$("body div#settings table tr#translater").click(function(){
		database.transaction(function(transaction){
			transaction.executeSql("SELECT * FROM `user` WHERE `rowid`=1", null, function(tx, results){
				let item = results.rows.item(0);
				$.ajax({
					method: "POST",
					url: urlSystem + "setStatusChat.php",
					data: {
						email: item.email,
						status:  "offline"
					}
				}).done(function(){
					goToPage("translater");
				});
			});
		});
	});
	
	$("body div#settings table tr#accountType").click(function(){
		database.transaction(function(transaction){
			transaction.executeSql("SELECT * FROM `user` WHERE `rowid`=1", null, function(tx, results){
				let item = results.rows.item(0);
				$.ajax({
					method: "POST",
					url: urlSystem + "setStatusChat.php",
					data: {
						email: item.email,
						status:  "offline"
					}
				}).done(function(){
					goToPage("accountType");
				});
			});
		});
	});
	
	$("body div#settings table tr#buyNow").click(function(){
		database.transaction(function(transaction){
			transaction.executeSql("SELECT * FROM `user` WHERE `rowid`=1", null, function(tx, results){
				let item = results.rows.item(0);
				$.ajax({
					method: "POST",
					url: urlSystem + "setStatusChat.php",
					data: {
						email: item.email,
						status:  "offline"
					}
				}).done(function(){
					goToPage("buyNow");
				});
			});
		});
	});
	
	$("body div#settings table tr#share").click(function(){
		window.plugins.socialsharing.shareWithOptions({
			message: "Quer aprender Inglês do melhor jeito e poder colocar em prática e conversar com outras pessoas de mesmo nível? Conheça o EnglishSwift e teste o aplicativo, baixe agora! http://bit.ly/EnglishSwift", subject: "O MELHOR JEITO DE APRENDER INGLÊS!", files: ["", ""], chooserTitle: "Compartilhar English Swift"}, function(){
				database.transaction(function(transaction){
					transaction.executeSql("SELECT * FROM `user` WHERE `rowid`=1", null, function(tx, results){
						let item = results.rows.item(0);
						$.ajax({
							method: "POST",
							url: urlSystem + "setStatusChat.php",
							data: {
								email: item.email,
								status:  "offline"
							}
						});
					});
				});
			}, function(){});
	});
	
	$("body div#settings table tr#rate").click(function(){
		LaunchReview.launch(function(){
			database.transaction(function(transaction){
				transaction.executeSql("SELECT * FROM `user` WHERE `rowid`=1", null, function(tx, results){
					let item = results.rows.item(0);
					$.ajax({
						method: "POST",
						url: urlSystem + "setStatusChat.php",
						data: {
							email: item.email,
							status:  "offline"
						}
					}).done(function(){});
				});
			});
		},function(err){
			dialog.alert("Houve algum erro ao abrir Play Store para avaliação, tente novamente.");
		}, packageApp);
	});
	$("body div#settings table tr#help").click(function(){		
		window.plugins.actionsheet.show({
			androidTheme: window.plugins.actionsheet.ANDROID_THEMES.THEME_DEVICE_DEFAULT_LIGHT,
			title: "Como deseja nos enviar um e-mail?",
			buttonLabels: ["Enviar e-mail pelo aplicativo English Swift", "Enviar e-mail pelo aplicativo nativo"],
			androidEnableCancelButton : true,
			addCancelButtonWithLabel: "Cancelar"
		}, function(buttonIndex){
			if(buttonIndex == 1){
				database.transaction(function(transaction){
					transaction.executeSql("SELECT * FROM `user` WHERE `rowid`=1", null, function(tx, results){
						let item = results.rows.item(0);
						$.ajax({
							method: "POST",
							url: urlSystem + "setStatusChat.php",
							data: {
								email: item.email,
								status:  "offline"
							}
						}).done(function(){
							goToPage("contact");
						});
					});
				});
			}
			else if(buttonIndex == 2){
				database.transaction(function(transaction){
					transaction.executeSql("SELECT * FROM `user` WHERE `rowid`=1", null, function(tx, results){
						let item = results.rows.item(0);
						$.ajax({
							method: "POST",
							url: urlSystem + "setStatusChat.php",
							data: {
								email: item.email,
								status:  "offline"
							}
						}).done(function(){
							window.open("mailto:englishswiftapp@gmail.com", "_system");
						});
					});
				});
			}
		});
	});
	
	$("body div#settings table tr#logout").click(function(){
		database.transaction(function(transaction){
			transaction.executeSql("SELECT * FROM `user` WHERE `rowid`=1", null, function(tx, results){
				let item = results.rows.item(0);
				$.ajax({
					method: "POST",
					url: urlSystem + "setStatusChat.php",
					data: {
						email: item.email,
						status:  "offline"
					}
				}).done(function(){
					dialog.startLoader("Saindo da conta...");
					setTimeout(function(){
						dialog.stopLoader();
						database.transaction(function(transaction){
							transaction.executeSql("DROP TABLE `user`", null, function(){
								if(localStorage.getItem("noBuyerFirst") != undefined) localStorage.removeItem("noBuyerFirst");
								localStorage.removeItem("logged");
								goToPage("options");
							});
						});
					}, 2000);
				});
			});
		});
	});
	
	$("body div#settings table tr#useTerms").click(function(){
		database.transaction(function(transaction){
			transaction.executeSql("SELECT * FROM `user` WHERE `rowid`=1", null, function(tx, results){
				let item = results.rows.item(0);
				$.ajax({
					method: "POST",
					url: urlSystem + "setStatusChat.php",
					data: {
						email: item.email,
						status:  "offline"
					}
				}).done(function(){
					sessionStorage.setItem("pageBack", "home");
					goToPage("useTerms");
				});
			});
		});
	});
	
	$("body div#settings table tr#privacy").click(function(){
		database.transaction(function(transaction){
			transaction.executeSql("SELECT * FROM `user` WHERE `rowid`=1", null, function(tx, results){
				let item = results.rows.item(0);
				$.ajax({
					method: "POST",
					url: urlSystem + "setStatusChat.php",
					data: {
						email: item.email,
						status:  "offline"
					}
				}).done(function(){
					sessionStorage.setItem("pageBack", "home");
					goToPage("privacy");
				});
			});
		});
	});
	
	$("body div#settings table tr#turnOff").click(function(){
		navigator.notification.confirm(
			"Tem certeza que deseja finalizar o aplicativo?",
			function(buttonIndex){
				if(buttonIndex == 1){
					database.transaction(function(transaction){
						transaction.executeSql("SELECT * FROM `user` WHERE `rowid`=1", null, function(tx, results){
							let item = results.rows.item(0);
							$.ajax({
								method: "POST",
								url: urlSystem + "setStatusChat.php",
								data: {
									email: item.email,
									status:  "offline"
								}
							}).done(function(){
								cordova.plugins.backgroundMode.moveToBackground();
							});
						});
					});
				}
			}, 
			"",
			["Sim", "Não"]
		);
	});
	
	database.transaction(function(transaction){
		transaction.executeSql("SELECT * FROM `bodyEmoji`", null, function(transaction, results){
			let length = results.rows.length;
			for(let c = 0;c < length;c++){
				$("body div#conversation div#chat div#emojis div#hands center").append("<button onClick='insertEmoji(`"+results.rows.item(c).code+"`);'>"+results.rows.item(c).code+"</button>");
			}
		});
		transaction.executeSql("SELECT * FROM `faceEmoji`", null, function(transaction, results){
			let length = results.rows.length;
			for(let c = 0;c < length;c++){
				$("body div#conversation div#chat div#emojis div#faces center").append("<button onClick='insertEmoji(`"+results.rows.item(c).code+"`);'>"+results.rows.item(c).code+"</button>");
			}
		});
		transaction.executeSql("SELECT * FROM `heartEmoji`", null, function(transaction, results){
			let length = results.rows.length;
			for(let c = 0;c < length;c++){
				$("body div#conversation div#chat div#emojis div#hearts center").append("<button onClick='insertEmoji(`"+results.rows.item(c).code+"`);'>"+results.rows.item(c).code+"</button>");
			}
		});
		transaction.executeSql("SELECT * FROM `animalEmoji`", null, function(transaction, results){
			let length = results.rows.length;
			for(let c = 0;c < length;c++){
				$("body div#conversation div#chat div#emojis div#pets center").append("<button onClick='insertEmoji(`"+results.rows.item(c).code+"`);'>"+results.rows.item(c).code+"</button>");
			}
		});
		transaction.executeSql("SELECT * FROM `treeEmoji`", null, function(transaction, results){
			let length = results.rows.length;
			for(let c = 0;c < length;c++){
				$("body div#conversation div#chat div#emojis div#trees center").append("<button onClick='insertEmoji(`"+results.rows.item(c).code+"`);'>"+results.rows.item(c).code+"</button>");
			}
		});
		transaction.executeSql("SELECT * FROM `foodEmoji`", null, function(transaction, results){
			let length = results.rows.length;
			for(let c = 0;c < length;c++){
				$("body div#conversation div#chat div#emojis div#foods center").append("<button onClick='insertEmoji(`"+results.rows.item(c).code+"`);'>"+results.rows.item(c).code+"</button>");
			}
		});
		transaction.executeSql("SELECT * FROM `transportEmoji`", null, function(transaction, results){
			let length = results.rows.length;
			for(let c = 0;c < length;c++){
				$("body div#conversation div#chat div#emojis div#transports center").append("<button onClick='insertEmoji(`"+results.rows.item(c).code+"`);'>"+results.rows.item(c).code+"</button>");
			}
		});
		transaction.executeSql("SELECT * FROM `clothesEmoji`", null, function(transaction, results){
			let length = results.rows.length;
			for(let c = 0;c < length;c++){
				$("body div#conversation div#chat div#emojis div#clothes center").append("<button onClick='insertEmoji(`"+results.rows.item(c).code+"`);'>"+results.rows.item(c).code+"</button>");
			}
		});
	});
	
	$("body div#conversation div#chat div#top table tr td#back").click(function(){
		goOutChat();
	});
	
	$("body div#conversation div#chat div#message table tr td#emojis").click(function(){
		let emojis = $("body div#conversation div#chat div#emojis").css("display");
		if(emojis == "none"){
			$("body div#conversation div#chat div#emojis").css("display", "block");
			$("body div#conversation div#chat div#messages").css("height", "calc(100vh - (4rem + 4.5rem + "+$("body div#conversation div#chat div#emojis").css("height")+"))");
		}
		else{
			$("body div#conversation div#chat div#emojis").css("display", "none");
			$("body div#conversation div#chat div#messages").css("height", "calc(100vh - (4rem + 4.5rem))");
		}
	});
	$("body div#conversation div#chat div#emojis table#listCategory tr td#close").click(function(){
		$("body div#conversation div#chat div#message table tr td#emojis").click();
	});
	
	$("body div#conversation div#chat div#message table tr td#field form#sendMessage #message").focus(function(){
		let emojis = $("body div#conversation div#chat div#emojis").css("display");
		if(emojis == "block"){
			$("body div#conversation div#chat div#emojis").css("display", "none");
			$("body div#conversation div#chat div#messages").css("height", "calc(100vh - (4rem + 4.5rem))");
		}
		$("body div#conversation div#chat div#message table tr td#emojis").css({
			borderTop: "1px solid white",
			borderLeft: "1px solid white",
			borderBottom: "1px solid white"
		});
		$("body div#conversation div#chat div#message table tr td#field").css({
			borderTop: "1px solid white",
			borderRight: "1px solid white",
			borderBottom: "1px solid white"
		});
		ConnectyCube.chat.sendIsTypingStatus(idUserChat);
	});
	
	$("body div#conversation div#chat div#message table tr td#field form#sendMessage #message").blur(function(){
		ConnectyCube.chat.sendIsStopTypingStatus(idUserChat);
	});
	
	$("body div#conversation div#chat div#message table tr td#field form#sendMessage").submit(function(e){
		e.preventDefault();
		let message = $("body div#conversation div#chat div#message table tr td#field form#sendMessage #message").val();
		if(message.length == 0){
			$("body div#conversation div#chat div#message table tr td#emojis").css({
				borderTop: "2px solid red",
				borderLeft: "2px solid red",
				borderBottom: "2px solid red"
			});
			$("body div#conversation div#chat div#message table tr td#field").css({
				borderTop: "2px solid red",
				borderRight: "2px solid red",
				borderBottom: "2px solid red"
			});
			M.toast({html: "Preencha para enviar.", "classes": "red", displayLength: 2000});
		}
		else{
			const settingsMessage = {
				type: "chat",
				body: message,
				extension: {
					save_to_history: 1
				},
				markable: 1
			};
			settingsMessage.id = ConnectyCube.chat.send(idUserChat, settingsMessage);
			$("body div#conversation div#chat div#message table tr td#field form#sendMessage #message").val("");
			
			ConnectyCube.chat.dialog.list({}).then(function(results){
				let items = results["items"];
				for(let c = 0; c < items.length; c++){
					let uID, occupantsIds = items[c]["occupants_ids"];
					if(occupantsIds[0] == myUserID) uID = occupantsIds[1];
					else if(occupantsIds[1] == myUserID) uID = occupantsIds[0];
					
					
					if(uID == idUserChat){
						let idDialog = items[c]["_id"];
						ConnectyCube.chat.message.list({chat_dialog_id: idDialog, sort_desc: "date_sent", limit: 10000, skip: 0}).then(function(messages){
						let m = messages["items"];
						for(let c = (m.length - 1); c >= 0; c--){
							let message = m[c]["message"];
							let senderId = m[c]["sender_id"];
							let dateMessage = m[c]["created_at"];
							let date = new Date(dateMessage);
							
		
							if(message == settingsMessage["body"]){
								let dateCreated = ((date.getDate() <= 9) ? "0" + date.getDate() : date.getDate()) + "/" + (((date.getMonth() + 1) <= 9) ? "0" + (date.getMonth() + 1) : (date.getMonth() + 1)) + "/" +  date.getFullYear();
								if(datesMessages.indexOf(dateCreated) < 0){
									datesMessages.push(dateCreated);
									$("body div#conversation div#chat div#messages").append('<center><br/><p class="date">'+dateCreated+'</p><br/></center>');
		
								}
								$("body div#conversation div#chat div#messages").append('<p class="send" onClick="copy(jQuery(this).text())">'+message+'</p>');
								
								if($("body div#chat div#messages div#fullMessages table#list tr#usr"+idUserChat).length == 0){
									$.getJSON(urlSystem + "getUserChat.php?userID=" + idUserChat, function(results){
										let picture = null;
										if(results["picture"] == "profile.png") picture = "img/profile.png";
										else picture = url + "profiles/" + results["picture"] + "?=" + date.getTime();
										$("body div#chat div#messages div#fullMessages table#list tr#usr" + idUserChat).remove();
										$("body div#chat div#messages div#fullMessages table#list").append('<tr id="usr'+idUserChat+'" onClick="startConversation('+idUserChat+');"><td class="icon" rowspan="2"><img alt="Foto de Perfil" src="'+picture+'" /></td><td class="name">'+results["fullName"]+'&nbsp;&nbsp;</td></tr><tr id="usr'+idUserChat+'" onClick="startConversation('+idUserChat+');"><td class="message" colspan="2">'+message+'</td></tr><tr id="usr'+idUserChat+'" style="height: 1.5rem;"></tr>');
									});
								}
								else $("body div#chat div#messages div#fullMessages table#list tr#usr"+idUserChat+" td.message").html(message);
								
								showMessagesOnSpace();
								$.getJSON(urlSystem + "sendMessageWithNotification.php?myUserID=" + myUserID + "&userID=" + idUserChat + "&message=" + settingsMessage["body"]);
								if($("body div#conversation div#chat div#messages div#down").css("display") == "none"){
									$("body div#conversation div#chat div#messages").animate({scrollTop: 999999999999999999999}, 1500);
								}
							}
							else if(c == 0){
								window.plugins.toast.show("Houve algum erro com a sua conexao.", "long", "center");
								goToPage("home");
							}
						}
					}).catch(function(error){
						console.log(error)
					});
					}
				}
			}).catch(function(error){
				console.log(error)
			});
		}
	});
	$("body div#conversation div#chat div#message table tr td#send").click(function(){
			$("body div#conversation div#chat div#message table tr td#field form#sendMessage").submit();
	});
	
	$("body div#conversation div#chat div#messages").scroll(function(event){
		let scrollT = $(this).scrollTop();
		let scrollH = $(this)[0].scrollHeight;
		let bottom = scrollH - scrollT;
		if(bottom >= 1000){
			$("body div#conversation div#chat div#messages div#down").css("display", "block");
		}
		else{
			$("body div#conversation div#chat div#messages div#down").css("display", "none");
		}
	});
	
	$("body div#conversation div#chat div#top table tr td#options").click(function(){
		window.plugins.actionsheet.show({
			androidTheme: window.plugins.actionsheet.ANDROID_THEMES.THEME_DEVICE_DEFAULT_LIGHT,
			title: "O que deseja fazer?",
			buttonLabels: ["Iniciar videochamada", "Iniciar chamada normal"],
			androidEnableCancelButton : false,
			addCancelButtonWithLabel: "Cancelar"
		}, function(buttonIndex){
			if(buttonIndex == 1 || buttonIndex == 2) dialog.alert("Funcionalidade em desenvolvimento.");
		});
	});
});

function showLesson(book){
	if($("body div#studies table tr#book"+book).css("display") == "none"){
		$("body div#studies table tr#book"+book).css("display", "revert");
	}
	else{
		$("body div#studies table tr#book"+book).css("display", "none");
	}
}
function selectLesson(lesson){
	sessionStorage.setItem("lessonSeleted", lesson);
	localStorage.setItem("pageNow", "lesson");
	window.open("lessons/lesson" + lesson + ".html", "_self");
}

function connectServer(){
	ConnectyCube.createSession().then(function(session){
		ConnectyCube.login(login).then(function(user){
			ConnectyCube.chat.onDisconnectedListener = function(){
				if(connected == 1){
					connected = 0;
					$("body div#chat div#loading").css("display", "block");
					if($("body div#conversation").css("display") == "block"){
						$("body div#conversation").css("display", "none");
						clearInterval(counterStatusFriend);
						inChat = 0;
						idUserChat = null;
						userChatStatus = 0;
						datesMessages = [];
						$("body div#conversation div#chat div#message table tr td#field form#sendMessage #message").val("");
						dialog.alert("Houve algum problema com a conexão, estamos reconectando.");
						$("body div#chat div#messages div#fullMessages table#list").html("");
						getAllMessages();		
						selectOptionChat("online");
						
					}
				}
			};
			ConnectyCube.chat.onReconnectListener = function(){
				if(connected == 0){
					connected = 1;
					$("body div#chat div#loading").css("display", "none");
				}
			};
			ConnectyCube.chat.connect(chat).then(function(){	
				connected = 1;			
				$("body div#chat div#loading").css("display", "none");
				getOnlines();
				getAllMessages();				
				ConnectyCube.chat.onMessageListener = function onMessage(userId, message){
					let messageReceived = message["body"];
					if(inChat == 1 && idUserChat == userId){
						let receivedMessageSound = document.getElementById("receivedMessage");
						receivedMessageSound.volume = 0.2;
						receivedMessageSound.play();
						let messageId = message["extension"]["message_id"];
						let dialogId = message["dialog_id"];
						ConnectyCube.chat.message.list({chat_dialog_id: dialogId, sort_desc: "date_sent", limit: 100000, skip: 0}).then(function(messages){
							let m = messages["items"];
							for(let c = (m.length - 1); c >= 0; c--){
								let id = m[c]["_id"];
								if(id == messageId){
									let dateMessage = m[c]["created_at"];
									let date = new Date(dateMessage);
				
									let dateCreated = ((date.getDate() <= 9) ? "0" + date.getDate() : date.getDate()) + "/" + (((date.getMonth() + 1) <= 9) ? "0" + (date.getMonth() + 1) : (date.getMonth() + 1)) + "/" +  date.getFullYear();
									if(datesMessages.indexOf(dateCreated) < 0){
										datesMessages.push(dateCreated);
										$("body div#conversation div#chat div#messages").append('<center><p class="date">'+dateCreated+'</p><br/></center>');
									}
									$("body div#chat div#messages div#fullMessages table#list tr#usr"+idUserChat+" td.message").html(messageReceived);
									showMessagesOnSpace();
									$("body div#conversation div#chat div#messages").append('<p class="received" onClick="copy(jQuery(this).text())">'+messageReceived+'</p>');
									
									if($("body div#conversation div#chat div#messages div#down").css("display") == "none"){
										$("body div#conversation div#chat div#messages").animate({scrollTop: 999999999999999999999}, 1500);
									}
								}
							}
						}).catch(function(error){
							console.log(error)
						});
					}
					else{
						$.getJSON(urlSystem + "getUserChat.php?userID=" + userId, function(results){
							let picture = null, pictureN;
							if(results["picture"] == "profile.png"){
								picture = "img/profile.png";
								pictureN= "file://img/profile.png";
							}
							else{
								picture = url + "profiles/" + results["picture"] + "?=" + date.getTime();
								pictureN = url + "profiles/" + results["picture"] + "?=" + date.getTime();
							}
							$("body div#chat div#messages div#fullMessages table#list tr#usr" + userId).remove();
							$("body div#chat div#messages div#fullMessages table#list").append('<tr id="usr'+userId+'" onClick="startConversation('+userId+');"><td class="icon" rowspan="2"><img alt="Foto de Perfil" src="'+picture+'" /></td><td class="name">'+results["fullName"]+'&nbsp;&nbsp;<span style="color: #1048c5;">NOVA</span></td></tr><tr id="usr'+userId+'" onClick="startConversation('+userId+');"><td class="message" colspan="2"><b>'+messageReceived+'</b></td></tr><tr id="usr'+userId+'" style="height: 1.5rem;"></tr>');
							showMessagesOnSpace();
							cordova.plugins.notification.local.schedule({
								id: userId,
								title: results["fullName"],
								text: messageReceived,
								smallIcon: "res://ic_notification",
								icon: pictureN,
								color: "1048c5",
								actions: [
									{id: "openChat", title: "Abrir chat"}
								]
							});
							cordova.plugins.notification.local.on("openChat", function(notification){
								let id = notification["id"];
								let date = new Date();
								let timeP = date.getHours() + ":" + date.getMinutes() + ":" + date.getSeconds();
								if(timeP != lastNotification){
									lastNotification = timeP;
									if(inChat == 1){
										$("body div#conversation").css("display", "none");
										inChat = 0;
										idUserChat = null;
										userChatStatus = 0;
										$("body div#conversation div#chat div#message table tr td#field form#sendMessage #message").val("");
										startConversation(id);
									}
									else startConversation(id);
								}
							});
						});
					}
					
				};
				ConnectyCube.chat.onMessageTypingListener = function (isTyping, userId, dialogId){
					if(inChat == 1 && idUserChat == userId){
						if(isTyping == true){
							$("body div#conversation div#chat div#top table tr td#info").text("Digitando...");
						}
						else{
							$.getJSON(urlSystem + "getUserChat.php?userID=" + userId, function(results){
								let status = results["status"];
								if(status == "online"){
									userChatStatus = 1;
									$("body div#conversation div#chat div#top table tr td#info").text("Online");
								}
								else{
									userChatStatus = 0;
									$("body div#conversation div#chat div#top table tr td#info").text(results["lastViewedDate"] + " - " + results["lastViewedTime"]);
								}
							});
						}
					}
				};
				
			}).catch(function(error){
				console.log(error);
			});
			
		}).catch(function(error){
			console.log(error);
		});
	});
}
function getOnlines(){
	database.transaction(function(transaction){
		transaction.executeSql("SELECT * FROM `user` WHERE `rowid`=1", null, function(tx, results){
			let item = results.rows.item(0);
			$.getJSON(urlSystem + "getOnlines.php?email=" + item.email, function(results){
				let length = results.length;
				$("body div#chat table#menu tr td button#online span").text("Online ("+length+")");
				if(length != 0){
					$("body div#chat div#online div#noneOnline").css("display", "none");
					$("body div#chat div#online div#fullOnline").css("display", "block");
					for(let c = 0; c < length; c++){
						let date = new Date();
						let picture = null;
						if(results[c]["picture"] == "profile.png") picture = "img/profile.png";
						else picture = url + "profiles/" + results[c]["picture"] + "?=" + date.getTime();
						$("body div#chat div.content div#fullOnline table").append('<tr id="usr'+results[c]["userID"]+'"><td class="icon" onClick="startConversation('+results[c]["userID"]+');"><img src="'+picture+'" alt="Foto de Perfil"/></td><td class="name" onClick="startConversation('+results[c]["userID"]+');">'+results[c]["fullName"]+'</td><td class="settings" onClick="optionsChat('+results[c]["userID"]+');"><i class="fa fa-ellipsis-v"></i></td></tr>');
						onlines.push(results[c]["userID"]);
						onlinesP2P.push(results[c]["p2pID"]);
					}
				}
			});
		});
	});
	counterOnline = setInterval(function(){
		database.transaction(function(transaction){
			transaction.executeSql("SELECT * FROM `user` WHERE `rowid`=1", null, function(tx, results){
				let item = results.rows.item(0);
				$.getJSON(urlSystem + "getOnlines.php?email=" + item.email, function(results){
					let length = results.length;
					$("body div#chat table#menu tr td button#online span").text("Online ("+length+")");
					if(length == 0){
						$("body div#chat div#online div#noneOnline").css("display", "block");
						$("body div#chat div#online div#fullOnline").css("display", "none");
						$("body div#chat div.content div#fullOnline table").html("");
						onlines = [];
						onlinesP2P = [];
					}
					else{
						$("body div#chat div#online div#noneOnline").css("display", "none");
						$("body div#chat div#online div#fullOnline").css("display", "block");
						for(let c = 0; c < length; c++){
							totalOnlines.push(results[c]["userID"]);
							if(onlines.indexOf(results[c]["userID"].toString()) > -1){
								onlinesP2P[onlines.indexOf(results[c]["userID"])] = results[c]["p2pID"];
							}
							else{
								let date = new Date();
								let picture = null;
								if(results[c]["picture"] == "profile.png") picture = "img/profile.png";
								else picture = url + "profiles/" + results[c]["picture"] + "?=" + date.getTime();
								$("body div#chat div.content div#fullOnline table").append('<tr id="usr'+results[c]["userID"]+'"><td class="icon" onClick="startConversation('+results[c]["userID"]+');"><img src="'+picture+'" alt="Foto de Perfil"/></td><td class="name" onClick="startConversation('+results[c]["userID"]+');">'+results[c]["fullName"]+'</td><td class="settings" onClick="optionsChat('+results[c]["userID"]+');"><i class="fa fa-ellipsis-v"></i></td></tr>');
								onlines.push(results[c]["userID"]);
								onlinesP2P.push(results[c]["p2pID"]);
							}
						}
					}
				});
				for(let c = 0; c < onlines.length; c++){
					if(totalOnlines.indexOf(onlines[c].toString()) < 0){
						$("body div#chat div.content div#fullOnline table tr#usr" + onlines[c]).remove();
						onlines.splice(c, 1);
						onlinesP2P.splice(c, 1);
					}
				}
				totalOnlines = [];
			});
		});
	}, 15000);
}

function startConversation(userID){
	if(accountType == 0){
		dialog.startLoader("Carregando...");
		counterMessagesLimit = 0;
		counterUserIdLimit = [];
		ConnectyCube.chat.dialog.list({}).then(function(results){
			let items = results["items"];
			if(items.length == 3){
				for(let c = 0; c < items.length; c++){
					let idDialog = items[c]["_id"];
					ConnectyCube.chat.message.list({chat_dialog_id: idDialog, sort_desc: "date_sent", limit: 10000, skip: 0}).then(function(messages){
						let i = messages["items"];
						for(let m = 0; m < i.length; m++){
							let senderId = i[m]["sender_id"];
							if(senderId == myUserID){
								let recipientID = i[m]["recipient_id"];
								if(recipientID != lastSenderId){
									lastSenderId = recipientID;
									counterMessagesLimit++;
									counterUserIdLimit.push(recipientID);
								}
							}
						}
						if(c == (items.length - 1)){
							if(counterMessagesLimit < 3){
								dialog.stopLoader();
								sConversation(userID);
							}
							else{
								setTimeout(function(){
									dialog.stopLoader();
									if(counterMessagesLimit == 3 && counterUserIdLimit.indexOf(userID) < 0){
										navigator.notification.confirm(
											"Conversar com mais de 3 pessoas é somente para pagantes.\nDeseja se tornar um agora?",
											function(buttonIndex){
												if(buttonIndex == 1) goToPage("buyNow");
											}, 
											"",
											["Sim", "Não"]
										);
									}
									else if(counterMessagesLimit == 3 && counterUserIdLimit.indexOf(userID) > -1){
										let date = new Date();			
										let hourE = parseInt(timeExpiration.split(":")[0]);
										let minutesE = parseInt(timeExpiration.split(":")[1]);
										let secondsE = parseInt(timeExpiration.split(":")[2]);			
										let dayE = parseInt(dateExpiration.split("/")[0]);
										let monthE = parseInt(dateExpiration.split("/")[1]);
										let yearE = parseInt(dateExpiration.split("/")[2]);
										
										if(date.getFullYear() <= yearE && (date.getMonth() + 1) <= monthE){
											if(date.getDate() < dayE){
												sConversation(userID);
											}
											else if(date.getDate() == dayE && date.getHours() <= hourE && date.getMinutes() <= minutesE){
												sConversation(userID);
											}
											else{
												navigator.notification.confirm(
													"Seu tempo para usar o chat expirou, agora é somente para pagantes.\nDeseja se tornar um agora?",
													function(buttonIndex){
														if(buttonIndex == 1) goToPage("buyNow");
													}, 
													"",
													["Sim", "Não"]
												);
											}
										}
										else{
											navigator.notification.confirm(
												"Seu tempo para usar o chat expirou, agora é somente para pagantes.\nDeseja se tornar um agora?",
												function(buttonIndex){
													if(buttonIndex == 1) goToPage("buyNow");
												}, 
												"",
												["Sim", "Não"]
											);
										}
									}
									else if(counterMessagesLimit < 3){
										sConversation(userID);
									}
								}, 500);
							}
						}
					}).catch(function(error){});
				}
			}
			else{
				dialog.stopLoader();
				let date = new Date();			
				let hourE = parseInt(timeExpiration.split(":")[0]);
				let minutesE = parseInt(timeExpiration.split(":")[1]);
				let secondsE = parseInt(timeExpiration.split(":")[2]);			
				let dayE = parseInt(dateExpiration.split("/")[0]);
				let monthE = parseInt(dateExpiration.split("/")[1]);
				let yearE = parseInt(dateExpiration.split("/")[2]);
				
				if(date.getFullYear() <= yearE && (date.getMonth() + 1) <= monthE){
					if(date.getDate() < dayE){
						sConversation(userID);
					}
					else if(date.getDate() == dayE && date.getHours() <= hourE && date.getMinutes() <= minutesE){
						sConversation(userID);
					}
					else{
						navigator.notification.confirm(
							"Seu tempo para usar o chat expirou, agora é somente para pagantes.\nDeseja se tornar um agora?",
							function(buttonIndex){
								if(buttonIndex == 1) goToPage("buyNow");
							}, 
							"",
							["Sim", "Não"]
						);
					}
				}
				else{
					navigator.notification.confirm(
						"Seu tempo para usar o chat expirou, agora é somente para pagantes.\nDeseja se tornar um agora?",
						function(buttonIndex){
							if(buttonIndex == 1) goToPage("buyNow");
						}, 
						"",
						["Sim", "Não"]
					);
				}
			}
		}).catch(function(error){});
	}
	else{
		sConversation(userID);
	}
}
function sConversation(userID){
	$.getJSON(urlSystem + "getUserChat.php?userID=" + userID, function(results){
		dialog.startLoader("Carregando...");
		sDialog = 1;
		let date = new Date();
		let picture = null;
		if(results["picture"] == "profile.png") picture = "img/profile.png";
		else picture = url + "profiles/" + results["picture"] + "?=" + date.getTime();
		$("body div#conversation div#chat div#top table tr td#picture img").attr("src", picture);
		$("body div#conversation div#chat div#top table tr td#nameUser").text(results["fullName"]);
		
		if(results["status"] == "online"){
			$("body div#conversation div#chat div#top table tr td#info").text("Online");
		}
		else{
			if(results["lastViewedDate"] == null) $("body div#conversation div#chat div#top table tr td#info").text("");
			else $("body div#conversation div#chat div#top table tr td#info").text(results["lastViewedDate"] + " - " + results["lastViewedTime"]);
		}
		
		$("body div#conversation div#chat div#messages").css("display", "block");
		$("body div#conversation").css("display", "block");
		$("body div#conversation div#chat div#message table tr td#field form#sendMessage #message").val("");
		$("body div#conversation div#chat div#messages").html("");
		$("body div#conversation div#chat div#messages").append('<div id="down" class="waves-effect" onClick="goDown();"><i class="fa fa-angle-double-down"></i></div>');
		inChat = 1;
		idUserChat = userID;
		userChatStatus = 1;
		counterStatusFriend = setInterval(function(){
			$.getJSON(urlSystem + "getUserChat.php?userID=" + idUserChat, function(r){
				if(r["status"] == "online"){
					$("body div#conversation div#chat div#top table tr td#info").text("Online");
				}
				else{
					if(r["lastViewedDate"] == null) $("body div#conversation div#chat div#top table tr td#info").text("");
					else $("body div#conversation div#chat div#top table tr td#info").text(r["lastViewedDate"] + " - " + r["lastViewedTime"]);
				}
			});
		}, 5000);
		ConnectyCube.chat.dialog.list({}).then(function(results){
			let items = results["items"];
			if(items.length == 0){
				if(sDialog == 1) sDialog = 0;
				dialog.stopLoader();
			}
			else{
				for(let c = 0; c < items.length; c++){
					let uID, occupantsIds = items[c]["occupants_ids"];
					if(occupantsIds[0] == myUserID) uID = occupantsIds[1];
					else if(occupantsIds[1] == myUserID) uID = occupantsIds[0];
					
					if(uID == userID){
						let idDialog = items[c]["_id"];
						ConnectyCube.chat.message.list({chat_dialog_id: idDialog, sort_desc: "date_sent", limit: 10000, skip: 0}).then(function(messages){
							let m = messages["items"];
							for(let c = (m.length - 1); c >= 0; c--){
								let message = m[c]["message"];
								let senderId = m[c]["sender_id"];
								let dateMessage = m[c]["created_at"];
								let date = new Date(dateMessage);
			
								let dateCreated = ((date.getDate() <= 9) ? "0" + date.getDate() : date.getDate()) + "/" + (((date.getMonth() + 1) <= 9) ? "0" + (date.getMonth() + 1) : (date.getMonth() + 1)) + "/" +  date.getFullYear();
								if(datesMessages.indexOf(dateCreated) < 0){
									datesMessages.push(dateCreated);
									$("body div#conversation div#chat div#messages").append('<center><br/><p class="date">'+dateCreated+'</p><br/></center>');
								}
								
								if(senderId == myUserID){
									$("body div#conversation div#chat div#messages").append('<p class="send" onClick="copy(jQuery(this).text())">'+message+'</p>');
								}
								else{
									$("body div#conversation div#chat div#messages").append('<p class="received" onClick="copy(jQuery(this).text())">'+message+'</p>');
								}
								$("body div#conversation div#chat div#messages").animate({scrollTop: 999999999999999999999}, 1);
								
								if(c == 0){
									if(sDialog == 1){
										sDialog = 0;
										dialog.stopLoader();
									}
								}
							}
						}).catch(function(error){
							console.log(error)
						});
					}
				}
				if(sDialog == 1){
					sDialog = 0;
					dialog.stopLoader();
				}
			}
		}).catch(function(error){
			console.log(error)
		});
	});
}
function optionsChat(userID){
	window.plugins.actionsheet.show({
		androidTheme: window.plugins.actionsheet.ANDROID_THEMES.THEME_DEVICE_DEFAULT_LIGHT,
		title: "O que deseja fazer?",
		buttonLabels: ["Conversar", "Iniciar videochamada", "Iniciar chamada normal"],
		androidEnableCancelButton : false,
		addCancelButtonWithLabel: "Cancelar"
	}, function(buttonIndex){
		if(buttonIndex == 1) startConversation(userID);
		if(buttonIndex == 2 || buttonIndex == 3) dialog.alert("Funcionalidade em desenvolvimento.");
	});
}

function selectOptionChat(option){
	let options = ["online", "messages", "calls"];
	
	for(let c = 0; c < options.length; c++){
		if(options[c] == option){
			$("body div#chat table#menu tr td button#" + options[c]).css("color", "#1048c5");
			$("body div#chat div#" + options[c]).css("display", "block");
		}
		else{
			$("body div#chat table#menu tr td button#" + options[c]).css("color", "black");
			$("body div#chat div#" + options[c]).css("display", "none");
		}
	}
}

function selectStory(story){
	if(accountType == 0){
		if(story > 5){
			navigator.notification.confirm(
				"Acesso dessa história somente para pagantes.\nDeseja se tornar um agora?",
				function(buttonIndex){
					if(buttonIndex == 1) goToPage("buyNow");
				}, 
				"",
				["Sim", "Não"]
			);
		}
		else{
			let date = new Date();			
			let hourE = parseInt(timeExpiration.split(":")[0]);
			let minutesE = parseInt(timeExpiration.split(":")[1]);
			let secondsE = parseInt(timeExpiration.split(":")[2]);			
			let dayE = parseInt(dateExpiration.split("/")[0]);
			let monthE = parseInt(dateExpiration.split("/")[1]);
			let yearE = parseInt(dateExpiration.split("/")[2]);
			
			if(date.getFullYear() <= yearE && (date.getMonth() + 1) <= monthE){
				if(date.getDate() < dayE){
					sessionStorage.setItem("storySelected", story);
					goToPage("story");
				}
				else if(date.getDate() == dayE && date.getHours() <= hourE && date.getMinutes() <= minutesE){
					sessionStorage.setItem("storySelected", story);
					goToPage("story");
				}
				else{
					navigator.notification.confirm(
						"Seu tempo para ouvir essa históra expirou, agora é somente para pagantes.\nDeseja se tornar um agora?",
						function(buttonIndex){
							if(buttonIndex == 1) goToPage("buyNow");
						}, 
						"",
						["Sim", "Não"]
					);
				}
			}
			else{
				navigator.notification.confirm(
					"Seu tempo para ouvir essa históra expirou, agora é somente para pagantes.\nDeseja se tornar um agora?",
					function(buttonIndex){
						if(buttonIndex == 1) goToPage("buyNow");
					}, 
					"",
					["Sim", "Não"]
				);
			}
		}
	}
	else{
		sessionStorage.setItem("storySelected", story);
		goToPage("story");
	}
}
function selectOptionPractise(option){
	let options = ["dictation", "question"];
	
	for(let c = 0; c < options.length; c++){
		if(options[c] == option){
			$("body div#practise table#menu tr td button#" + options[c]).css("color", "#1048c5");
			$("body div#practise div#" + options[c]).css("display", "block");
		}
		else{
			$("body div#practise table#menu tr td button#" + options[c]).css("color", "black");
			$("body div#practise div#" + options[c]).css("display", "none");
		}
	}
}
function showDictations(book){
	if($("body div#practise div#dictation table tr#book"+book).css("display") == "none"){
		$("body div#practise div#dictation table tr#book"+book).css("display", "revert");
	}
	else{
		$("body div#practise div#dictation table tr#book"+book).css("display", "none");
	}
}

function selectDictation(dictation, lesson){
	if(accountType == 0){
		if(lesson == 1){
			let date = new Date();			
			let hourE = parseInt(timeExpiration.split(":")[0]);
			let minutesE = parseInt(timeExpiration.split(":")[1]);
			let secondsE = parseInt(timeExpiration.split(":")[2]);			
			let dayE = parseInt(dateExpiration.split("/")[0]);
			let monthE = parseInt(dateExpiration.split("/")[1]);
			let yearE = parseInt(dateExpiration.split("/")[2]);
			
			if(date.getFullYear() <= yearE && (date.getMonth() + 1) <= monthE){
				if(date.getDate() < dayE){
					sessionStorage.setItem("dictationSelected", dictation);
					goToPage("dictation");
				}
				else if(date.getDate() == dayE && date.getHours() <= hourE && date.getMinutes() <= minutesE){
					sessionStorage.setItem("dictationSelected", dictation);
					goToPage("dictation");
				}
				else{
					navigator.notification.confirm(
						"Seu tempo para fazer esse ditado expirou, agora é somente para pagantes.\nDeseja se tornar um agora?",
						function(buttonIndex){
							if(buttonIndex == 1) goToPage("buyNow");
						}, 
						"",
						["Sim", "Não"]
					);
				}
			}
			else{
				navigator.notification.confirm(
					"Seu tempo para fazer esse ditado expirou, agora é somente para pagantes.\nDeseja se tornar um agora?",
					function(buttonIndex){
						if(buttonIndex == 1) goToPage("buyNow");
					}, 
					"",
					["Sim", "Não"]
				);
			}
		}
		else{
			navigator.notification.confirm(
				"Acesso desse ditado somente para pagantes.\nDeseja se tornar um agora?",
				function(buttonIndex){
					if(buttonIndex == 1) goToPage("buyNow");
				}, 
				"",
				["Sim", "Não"]
			);
		}
	}
	else{
		sessionStorage.setItem("dictationSelected", dictation);
		goToPage("dictation");
	}
}

function showQuestions(book){
	if($("body div#practise div#question table tr#book"+book).css("display") == "none"){
		$("body div#practise div#question table tr#book"+book).css("display", "revert");
	}
	else{
		$("body div#practise div#question table tr#book"+book).css("display", "none");
	}
}

function selectQuestion(question, stage){
	if(accountType == 0){
		if(stage == 1){
			let date = new Date();			
			let hourE = parseInt(timeExpiration.split(":")[0]);
			let minutesE = parseInt(timeExpiration.split(":")[1]);
			let secondsE = parseInt(timeExpiration.split(":")[2]);			
			let dayE = parseInt(dateExpiration.split("/")[0]);
			let monthE = parseInt(dateExpiration.split("/")[1]);
			let yearE = parseInt(dateExpiration.split("/")[2]);
			
			if(date.getFullYear() <= yearE && (date.getMonth() + 1) <= monthE){
				if(date.getDate() < dayE){
					sessionStorage.setItem("revisionSelected", question);
					goToPage("revision");
				}
				else if(date.getDate() == dayE && date.getHours() <= hourE && date.getMinutes() <= minutesE){
					sessionStorage.setItem("revisionSelected", question);
					goToPage("revision");
				}
				else{
					navigator.notification.confirm(
						"Seu tempo para fazer esse exercício de revisão expirou, agora é somente para pagantes.\nDeseja se tornar um agora?",
						function(buttonIndex){
							if(buttonIndex == 1) goToPage("buyNow");
						}, 
						"",
						["Sim", "Não"]
					);
				}
			}
			else{
				navigator.notification.confirm(
					"Seu tempo para fazer esse exercício de revisão expirou, agora é somente para pagantes.\nDeseja se tornar um agora?",
					function(buttonIndex){
						if(buttonIndex == 1) goToPage("buyNow");
					}, 
					"",
					["Sim", "Não"]
				);
			}
		}
		else{
			navigator.notification.confirm(
				"Acesso desse exercício de revisão somente para pagantes.\nDeseja se tornar um agora?",
				function(buttonIndex){
					if(buttonIndex == 1) goToPage("buyNow");
				}, 
				"",
				["Sim", "Não"]
			);
		}
	}
	else{
		sessionStorage.setItem("revisionSelected", question);
		goToPage("revision");
	}
}

function setPage(page){
	let options = ["studies", "chat", "stories", "practise", "settings"];
	
	if(page == "stories"){
		if(warnStories == 0){
			warnStories = 1;
			window.HeadsetDetection.detect(function(detected){
				if(detected == false){
					dialog.alert("Para uma melhor experiência e aprendizado, recomendamos que escute as histórias usando um fone de ouvido.");
				}
			});
		}
	}
	
	for(let c = 0;  c < options.length; c++){
		if(options[c] == page){
			$("body nav#menu table tr td#" + options[c] + " button").attr("class", "selected");
			$("body div#" + options[c]).css("display", "block");
		}
		else{
			$("body nav#menu table tr td#" + options[c] + " button").attr("class", "unselected");
			$("body div#" + options[c]).css("display", "none");
		}		
	}
}

function selectOptionEmoji(option){
	let options = ["hands", "faces", "hearts", "pets", "trees", "foods", "transports", "clothes"];
	for(let c = 0;c < options.length; c++){
		if(options[c] == option){
			$("body div#conversation div#chat table#listCategory tr td#" + options[c]).css("borderBottom", "4px solid #1048c5");
			$("body div#conversation div#chat div#" + options[c]).css("display", "block");
		}
		else{
			$("body div#conversation div#chat table#listCategory tr td#" + options[c]).css("borderBottom", "0");
			$("body div#conversation div#chat div#" + options[c]).css("display", "none");
		}
	}
}
function insertEmoji(emoji){
	let message = $("body div#conversation div#chat div#message table tr td#field form#sendMessage #message").val();
	$("body div#conversation div#chat div#message table tr td#field form#sendMessage #message").val(message + emoji);
}

function getAllMessages(){
	ConnectyCube.chat.dialog.list({}).then(function(results){
		let items = results["items"];
		if(items.length == 0){
			$("body div#chat div#messages div#chargingMessages").css("display", "none");
			$("body div#chat div#messages div#none").css("display", "block");
		}
		else{
			for(let c = 0; c < items.length; c++){
				let idDialog = items[c]["_id"];
				let userId = items[c]["user_id"];
				ConnectyCube.chat.message.list({chat_dialog_id: idDialog, sort_desc: "date_sent", limit: 10000, skip: 0}).then(function(messages){
					let item = messages["items"][0];
					let senderId = item["sender_id"];
					if(senderId == myUserID){
						let recipientID = item["recipient_id"];
						$.getJSON(urlSystem + "getUserChat.php?userID=" + recipientID, function(results){
							let date = new Date();
							let picture = null;
							if(results["picture"] == "profile.png") picture = "img/profile.png";
							else picture = url + "profiles/" + results["picture"] + "?=" + date.getTime();
							$("body div#chat div#messages div#fullMessages table#list").append('<tr id="usr'+recipientID+'" onClick="startConversation('+recipientID+');"><td class="icon" rowspan="2"><img alt="Foto de Perfil" src="'+picture+'" /></td><td class="name">'+results["fullName"]+'</td></tr><tr id="usr'+recipientID+'" onClick="startConversation('+recipientID+');"><td class="message" colspan="2">Você: '+item["message"]+'</td></tr><tr style="height: 1.5rem;" id="usr'+recipientID+'"></tr>');
						});
					}
					else{
						let recipientID = item["recipient_id"];
						if(item["read_ids"].indexOf(recipientID) > -1){
							$.getJSON(urlSystem + "getUserChat.php?userID=" + senderId, function(results){
								let date = new Date();
								let picture = null;
								if(results["picture"] == "profile.png") picture = "img/profile.png";
								else picture = url + "profiles/" + results["picture"] + "?=" + date.getTime();
								$("body div#chat div#messages div#fullMessages table#list").append('<tr id="usr'+senderId+'" onClick="startConversation('+senderId+');"><td class="icon" rowspan="2"><img alt="Foto de Perfil" src="'+picture+'" /></td><td class="name">'+results["fullName"]+'</td></tr><tr id="usr'+senderId+'" onClick="startConversation('+senderId+');"><td class="message" colspan="2">'+item["message"]+'</td></tr><tr style="height: 1.5rem;" id="usr'+senderId+'"></tr>');
							});
						}
						else{
							if(warnNewMessages == 0){
								warnNewMessages = 1;
								M.toast({html: "Você tem novas mensagens.", classes: "blue", displayLength: 2000});
							}
							$.getJSON(urlSystem + "getUserChat.php?userID=" + senderId, function(results){
								let date = new Date();
								let picture = null;
								if(results["picture"] == "profile.png") picture = "img/profile.png";
								else picture = url + "profiles/" + results["picture"] + "?=" + date.getTime();
								$("body div#chat div#messages div#fullMessages table#list").append('<tr id="usr'+senderId+'" onClick="startConversation('+senderId+');"><td class="icon" rowspan="2"><img alt="Foto de Perfil" src="'+picture+'" /></td><td class="name">'+results["fullName"]+'&nbsp;&nbsp;<span style="color: #1048c5;">NOVA</span></td></tr><tr id="usr'+senderId+'" onClick="startConversation('+senderId+');"><td class="message" colspan="2"><b>'+item["message"]+'</b></td></tr><tr style="height: 1.5rem;" id="usr'+senderId+'"></tr>');
							});
						}
					}
				}).catch(function(error){
					console.log(error)
				});
			}
			$("body div#chat div#messages div#chargingMessages").css("display", "none");
			$("body div#chat div#messages div#fullMessages").css("display", "block");
		}
	}).catch(function(error){
		console.log(error)
	});
}
function showMessagesOnSpace(){
	$("body div#chat div#messages div#none").css("display", "none");
	$("body div#chat div#messages div#fullMessages").css("display", "block");
}
function goOutChat(){
	if($("body div#conversation").css("display") == "block"){
		clearInterval(counterStatusFriend);
		$("body div#chat div#messages div#fullMessages table#list tr#usr"+idUserChat+" td.name span").remove();
		$("body div#chat div#messages div#fullMessages table#list tr#usr"+idUserChat+" td.message b").css("fontWeight", "normal");
		$("body div#conversation").css("display", "none");
		inChat = 0;
		idUserChat = null;
		userChatStatus = 0;
		datesMessages = [];
		$("body div#conversation div#chat div#message table tr td#field form#sendMessage #message").val("");
	}
}
function goDown(){
	$("body div#conversation div#chat div#messages").animate({scrollTop: 999999999999999999999}, 1500);
}

function copy(text){
	/*Double Click */
  if((new Date().getTime() - touchtime) < delay){
     clearTimeout(action)
     cordova.plugins.clipboard.copy(text);
	 window.plugins.toast.show("Mensagem copiada.", "short", "bottom");
     touchtime = 0;
  }
  /* Single Click */
  else{
     touchtime = new Date().getTime();
     action = setTimeout(function(){},delay);
  }
}