$("document").ready(function(){
	localStorage.setItem("pageNow", "login");
	
	if(sessionStorage.getItem("registerSuccess") != undefined){
		sessionStorage.removeItem("registerSuccess");
		M.toast({html: "Conta registrada com sucesso!", classes: "blue", "displayLength": 2000});
	}
	
	$("body div#login form#login label input").focus(function(){
		$(this).css("border", "1px solid #f5f6fa");
	});
	
	$("body div#login form#login").submit(function(e){
		e.preventDefault();
		
		let email = $("body div#login form#login label #email").val();
		let password = $("body div#login form#login label #password").val();
		
		if(email.length == 0 || password.length == 0){
			if(email.length == 0) $("body div#login form#login label #email").css("border", "1px solid red");
			if(password.length == 0) $("body div#login form#login label #password").css("border", "1px solid red");
			M.toast({html: "Preencha todos os campos.", classes: "red", displayLength: 2000});
		}
		else if(verifyEmail(email) == false){
			$("body div#login form#login label #email").css("border", "1px solid red");
			M.toast({html: "E-mail inválido.", classes: "red", displayLength: 2000});
		}
		else if(password.length < 8){
			$("body div#login form#login label #password").css("border", "1px solid red");
			M.toast({html: "Senha tem no mínimo 8 dígitos.", classes: "red", displayLength: 2000});
		}
		else{
			dialog.startLoader("Entrando...");
			$.ajax({
				method: "POST", 
				url: urlSystem + "login.php", 
				data: {
					email: email, 
					password: md5(password)
				}
			}).done(function(r){
				dialog.stopLoader();
				if(r == 1){
					navigator.notification.confirm(
						"Conta não existe, deseja se cadastrar?",
						function(buttonIndex){
							if(buttonIndex == 1) goToPage("register");
						}, 
						"",
						["Sim", "Não"]
					);
				}
				else if(r == 2){
					dialog.alert("Senha incorreta.");
					$("body div#login form#login label #password").css("border", "1px solid red");
				}
				else{
					let results = JSON.parse(r);
					console.log(results);
					console.log('INSERT INTO `user` (`email`, `fullName`, `birthDate`, `phoneNumber`, `picture`, `dateRegistration`, `timeRegistration`) VALUES ("'+results["email"]+'", "'+results["fullName"]+'", "'+results["birthDate"]+'", "'+results["phoneNumber"]+'", "'+results["picture"]+'", "'+results["dateRegistration"]+'", "'+results["timeRegistration"]+'")')
					database.transaction(function(transaction){
						transaction.executeSql('INSERT INTO `user` (`email`, `fullName`, `birthDate`, `phoneNumber`, `picture`, `dateRegistration`, `timeRegistration`) VALUES ("'+results["email"]+'", "'+results["fullName"]+'", "'+results["birthDate"]+'", "'+results["phoneNumber"]+'", "'+results["picture"]+'", "'+results["dateRegistration"]+'", "'+results["timeRegistration"]+'")', null, function(){
							localStorage.setItem("logged", 1);
							goToPage("home");
						});
					});
				}
			});
		}
	});
	
	$("body div#login form#login p#forgotPassword").click(function(){
		goToPage("recoveryPassword");
	});
	
	$("body div#login form#login p#register").click(function(){
		goToPage("register");
	});
});
function verifyEmail(email){
	let x = email;
	let atpos = x.indexOf("@");
	let dotpos = x.lastIndexOf(".");
	if (atpos<1 || dotpos<atpos+2 || dotpos+2>=x.length){
		return false;
	}
	else{
		return true;
	}
}